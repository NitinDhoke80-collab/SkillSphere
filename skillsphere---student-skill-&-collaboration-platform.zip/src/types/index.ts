export type SkillStatus = 'proficient' | 'learning' | 'want_to_learn';

export type PostType = 'project_update' | 'achievement' | 'collaborator_request' | 'general';

export type BadgeCategory = 'hackathon' | 'academic' | 'leadership';
export type BadgeTier = 'gold' | 'silver' | 'bronze' | 'special';

export interface StudentBadge {
  id: string;
  student_id: string;
  category: BadgeCategory;
  title: string;
  issuer: string;
  date_earned: string;
  description: string;
  icon_name: 'Trophy' | 'Medal' | 'Award' | 'GraduationCap' | 'BookOpen' | 'Crown' | 'Flame' | 'ShieldCheck';
  tier: BadgeTier;
  verification_url?: string;
  verified: boolean;
  verifier_name?: string;
  created_at: string;
}

export interface Profile {
  id: string;
  username: string;
  full_name: string;
  avatar_url: string;
  university: string;
  major: string;
  grad_year: number;
  bio: string;
  learning_goals: string[];
  private_weaknesses?: string; // Private by default, RLS protected
  contact_email?: string; // Private by default
  github_url?: string;
  linkedin_url?: string;
  portfolio_url?: string;
  badges?: StudentBadge[];
  created_at: string;
  updated_at: string;
}

export interface Skill {
  id: string;
  name: string;
  category: 'Web Development' | 'AI & Machine Learning' | 'Systems & Cloud' | 'UI/UX Design' | 'Data Science' | 'Mobile & Game';
  description: string;
  verified_count: number;
  icon_name?: string;
}

export interface ProfileSkill {
  id: string;
  profile_id: string;
  skill_id: string;
  skill?: Skill;
  status: SkillStatus;
  endorsements_count: number;
  endorsed_by?: string[]; // IDs of users who endorsed
  created_at: string;
}

export interface Post {
  id: string;
  author_id: string;
  author?: Profile;
  post_type: PostType;
  text_content: string;
  image_path?: string;
  project_title?: string;
  project_repo?: string;
  looking_for_skills?: string[];
  likes_count: number;
  comments_count: number;
  user_has_liked?: boolean;
  user_has_bookmarked?: boolean;
  created_at: string;
}

export interface Like {
  id: string;
  post_id: string;
  user_id: string;
  created_at: string;
}

export interface Comment {
  id: string;
  post_id: string;
  author_id: string;
  author?: Profile;
  text_content: string;
  created_at: string;
}

export interface CollaborationRequest {
  id: string;
  post_id: string;
  sender_id: string;
  sender?: Profile;
  receiver_id: string;
  message: string;
  skill_offered: string;
  status: 'pending' | 'accepted' | 'declined';
  created_at: string;
}

export interface SupabaseConfig {
  supabaseUrl: string;
  supabaseAnonKey: string;
  isConnected: boolean;
}
