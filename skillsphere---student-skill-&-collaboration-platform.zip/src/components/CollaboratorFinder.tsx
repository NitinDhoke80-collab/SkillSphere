import React, { useState } from 'react';
import { useSkillSphere } from '../services/store';
import { Profile } from '../types';
import { filterStudents, calculateSkillMatchScore } from '../utils/pureLogic';
import { CollabRequestModal } from './CollabRequestModal';
import { BadgeSystem } from './BadgeSystem';
import {
  Users,
  Search,
  Filter,
  CheckCircle2,
  ExternalLink,
  Target,
  Award,
  Sparkles,
  Star,
} from 'lucide-react';

export const CollaboratorFinder: React.FC = () => {
  const {
    allUsers,
    currentUser,
    profileSkills,
    skills,
    searchQuery,
    setSearchQuery,
    selectedSkillFilter,
    setSelectedSkillFilter,
    setActiveView,
    setViewingProfileId,
  } = useSkillSphere();

  const [selectedUniversity, setSelectedUniversity] = useState<string>('all');
  const [selectedStudentForCollab, setSelectedStudentForCollab] = useState<Profile | null>(null);

  // List of unique universities for filter
  const universities = ['all', ...Array.from(new Set(allUsers.map((u) => u.university)))];

  // Primary popular skills for quick pill filtering
  const popularSkills = ['All', 'React', 'PyTorch', 'TypeScript', 'PostgreSQL & Supabase', 'Figma', 'Docker & Containers', 'Rust'];

  // Filter students
  const filteredStudents = filterStudents(
    allUsers,
    profileSkills,
    searchQuery,
    selectedSkillFilter === 'All' ? '' : selectedSkillFilter
  ).filter((student) => {
    if (selectedUniversity !== 'all' && student.university !== selectedUniversity) {
      return false;
    }
    return true;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Page Header */}
      <div className="bg-white border border-slate-200/90 rounded-3xl p-6 sm:p-8 shadow-xs">
        <div className="max-w-3xl">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-blue-50 text-blue-700 border border-blue-200 mb-3">
            <Users className="w-3.5 h-3.5 text-blue-600" />
            Peer Collaboration Matcher
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            Find Student Collaborators by Verified Skill
          </h1>
          <p className="text-sm text-slate-600 mt-2 leading-relaxed">
            Connect with college students across campus who possess complementary technical skills for hackathons, capstone projects, and ambitious startup ideas.
          </p>
        </div>

        {/* Filter Controls */}
        <div className="mt-6 pt-6 border-t border-slate-100 space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-3">
            {/* Search Input */}
            <div className="md:col-span-8 relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search by student name, major, or tech stack..."
                className="w-full bg-slate-100/80 border border-slate-200 rounded-xl pl-10 pr-4 py-2.5 text-xs sm:text-sm text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 focus:bg-white"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-slate-700"
                >
                  Clear
                </button>
              )}
            </div>

            {/* University Filter */}
            <div className="md:col-span-4">
              <select
                value={selectedUniversity}
                onChange={(e) => setSelectedUniversity(e.target.value)}
                className="w-full bg-slate-100/80 border border-slate-200 rounded-xl px-3 py-2.5 text-xs sm:text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 focus:bg-white"
              >
                <option value="all">All Universities</option>
                {universities.filter((u) => u !== 'all').map((uni) => (
                  <option key={uni} value={uni}>
                    {uni}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Quick Skill Filter Pills */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
            <span className="text-xs font-semibold text-slate-400 mr-1 shrink-0 flex items-center gap-1">
              <Filter className="w-3 h-3" />
              Skill:
            </span>
            {popularSkills.map((skillName) => {
              const isSelected =
                (selectedSkillFilter === '' && skillName === 'All') ||
                selectedSkillFilter.toLowerCase() === skillName.toLowerCase();
              return (
                <button
                  key={skillName}
                  onClick={() => setSelectedSkillFilter(skillName === 'All' ? '' : skillName)}
                  className={`px-3 py-1 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                    isSelected
                      ? 'bg-blue-600 text-white shadow-xs'
                      : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                  }`}
                >
                  {skillName}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Results Count */}
      <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
        <span>Showing {filteredStudents.length} student builders</span>
        {selectedSkillFilter && (
          <span>
            Filtered by: <strong className="text-indigo-600 dark:text-indigo-400">{selectedSkillFilter}</strong>
          </span>
        )}
      </div>

      {/* Student Cards Grid */}
      {filteredStudents.length === 0 ? (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-12 text-center shadow-sm">
          <Users className="w-10 h-10 text-slate-300 dark:text-slate-600 mx-auto mb-3" />
          <h3 className="text-base font-semibold text-slate-800 dark:text-slate-200">
            No students found matching your criteria
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-sm mx-auto">
            Try resetting your filters or selecting a different skill from the catalogue.
          </p>
          <button
            onClick={() => {
              setSearchQuery('');
              setSelectedSkillFilter('');
              setSelectedUniversity('all');
            }}
            className="mt-4 px-4 py-2 rounded-xl bg-indigo-600 text-white text-xs font-semibold shadow-sm"
          >
            Reset Filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredStudents.map((student) => {
            const studentSkills = profileSkills.filter((ps) => ps.profile_id === student.id);
            const proficient = studentSkills.filter((ps) => ps.status === 'proficient');
            const isSelf = student.id === currentUser.id;

            // Calculate skill match score if filter is active
            const matchScore = selectedSkillFilter
              ? calculateSkillMatchScore(
                  proficient.map((p) => p.skill?.name || ''),
                  [selectedSkillFilter]
                )
              : null;

            return (
              <div
                key={student.id}
                className="bg-white border border-slate-200/90 rounded-3xl p-6 shadow-xs hover:shadow-md transition-all flex flex-col justify-between group"
              >
                <div>
                  {/* Top: Avatar & Meta */}
                  <div className="flex items-start justify-between gap-3 mb-4">
                    <div className="flex items-center gap-3">
                      <img
                        src={student.avatar_url}
                        alt={student.full_name}
                        className="w-13 h-13 rounded-2xl object-cover ring-2 ring-blue-500/20 group-hover:ring-blue-500 transition-all"
                      />
                      <div>
                        <h3 className="font-bold text-slate-900 text-sm group-hover:text-blue-600 transition-colors">
                          {student.full_name}
                        </h3>
                        <p className="text-xs text-slate-400">@{student.username}</p>
                        <p className="text-xs font-semibold text-blue-600 mt-0.5">
                          {student.university}
                        </p>
                      </div>
                    </div>

                    {isSelf ? (
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 border border-slate-200">
                        You
                      </span>
                    ) : matchScore && matchScore.matchCount > 0 ? (
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200 flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                        Match
                      </span>
                    ) : null}
                  </div>

                  {/* Major & Grad Year */}
                  <p className="text-xs text-slate-500 mb-2.5">
                    {student.major} · Class of &apos;{student.grad_year}
                  </p>

                  {/* Earned Badges - Hackathon Wins & Academic Milestones */}
                  <div className="mb-3.5">
                    <BadgeSystem studentId={student.id} variant="compact" maxDisplay={2} />
                  </div>

                  {/* Bio */}
                  <p className="text-xs text-slate-700 line-clamp-3 leading-relaxed mb-4">
                    {student.bio}
                  </p>

                  {/* Proficient Skills */}
                  <div className="mb-4">
                    <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block mb-1.5 flex items-center gap-1">
                      <Award className="w-3 h-3 text-blue-600" />
                      Proficient Skills ({proficient.length})
                    </span>
                    <div className="flex flex-wrap gap-1.5">
                      {proficient.slice(0, 4).map((ps) => (
                        <span
                          key={ps.id}
                          className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-medium bg-slate-100 text-slate-800 border border-slate-200/60"
                        >
                          <span>{ps.skill?.name}</span>
                          {ps.endorsements_count > 0 && (
                            <span className="inline-flex items-center text-[10px] text-amber-700 font-bold ml-0.5">
                              <Star className="w-2.5 h-2.5 fill-current inline mr-0.5 text-amber-500" />
                              {ps.endorsements_count}
                            </span>
                          )}
                        </span>
                      ))}
                      {proficient.length > 4 && (
                        <span className="px-1.5 py-1 text-[11px] text-slate-400">
                          +{proficient.length - 4} more
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Learning Goals */}
                  {student.learning_goals && student.learning_goals.length > 0 && (
                    <div className="mb-4 pt-3 border-t border-slate-100">
                      <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block mb-1 flex items-center gap-1">
                        <Target className="w-3 h-3 text-amber-600" />
                        Learning Goals:
                      </span>
                      <p className="text-xs text-slate-600 truncate">
                        {student.learning_goals.join(' · ')}
                      </p>
                    </div>
                  )}
                </div>

                {/* Bottom Actions */}
                <div className="pt-4 border-t border-slate-100 flex items-center gap-2">
                  <button
                    onClick={() => {
                      setViewingProfileId(student.id);
                      setActiveView('profile');
                    }}
                    className="flex-1 py-2 rounded-xl border border-slate-200 text-slate-700 text-xs font-semibold hover:bg-slate-50 transition-colors"
                  >
                    View Profile
                  </button>

                  {!isSelf && (
                    <button
                      onClick={() => setSelectedStudentForCollab(student)}
                      className="flex-1 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold shadow-xs transition-all flex items-center justify-center gap-1.5"
                    >
                      <Users className="w-3.5 h-3.5" />
                      Collaborate
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Collab Request Modal */}
      <CollabRequestModal
        isOpen={!!selectedStudentForCollab}
        onClose={() => setSelectedStudentForCollab(null)}
        targetStudent={selectedStudentForCollab}
      />
    </div>
  );
};
