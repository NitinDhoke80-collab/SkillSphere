import React, { useState } from 'react';
import { useSkillSphere } from '../services/store';
import { PostCard } from './PostCard';
import { EditProfileModal } from './EditProfileModal';
import { BadgeSystem } from './BadgeSystem';
import { SkillStatus } from '../types';
import {
  Shield,
  ShieldCheck,
  ShieldAlert,
  ThumbsUp,
  Award,
  BookOpen,
  Target,
  Edit3,
  ExternalLink,
  Plus,
  Trash2,
  Lock,
} from 'lucide-react';
import confetti from 'canvas-confetti';

export const ProfileView: React.FC = () => {
  const {
    currentUser,
    allUsers,
    viewingProfileId,
    setViewingProfileId,
    profileSkills,
    skills,
    posts,
    addOrUpdateSkill,
    removeSkill,
    endorseSkill,
  } = useSkillSphere();

  const [isEditOpen, setIsEditOpen] = useState(false);
  const [isAddSkillOpen, setIsAddSkillOpen] = useState(false);
  const [selectedSkillId, setSelectedSkillId] = useState('');
  const [selectedStatus, setSelectedStatus] = useState<SkillStatus>('proficient');

  // Determine active profile to display
  const profileIdToLoad = viewingProfileId || currentUser.id;
  const profile = allUsers.find((u) => u.id === profileIdToLoad) || currentUser;
  const isOwnProfile = profile.id === currentUser.id;

  // Student's skills
  const studentProfileSkills = profileSkills.filter((ps) => ps.profile_id === profile.id);
  const proficientSkills = studentProfileSkills.filter((ps) => ps.status === 'proficient');
  const learningSkills = studentProfileSkills.filter((ps) => ps.status === 'learning');
  const wantToLearnSkills = studentProfileSkills.filter((ps) => ps.status === 'want_to_learn');

  // Student's authored posts
  const studentPosts = posts.filter((p) => p.author_id === profile.id);

  // Available skills to add (excluding ones already added)
  const existingSkillIds = new Set(studentProfileSkills.map((ps) => ps.skill_id));
  const availableSkillsToAdd = skills.filter((s) => !existingSkillIds.has(s.id));

  const handleEndorse = (profileSkillId: string) => {
    const success = endorseSkill(profileSkillId);
    if (success) {
      confetti({
        particleCount: 20,
        spread: 50,
        origin: { y: 0.7 },
      });
    }
  };

  const handleAddSkillSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedSkillId) return;
    addOrUpdateSkill(selectedSkillId, selectedStatus);
    setIsAddSkillOpen(false);
    setSelectedSkillId('');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Profile Header Card */}
      <div className="bg-white border border-slate-200/90 rounded-3xl overflow-hidden shadow-xs">
        {/* Banner - Light Clean Collegiate Aesthetic */}
        <div className="h-44 sm:h-48 bg-gradient-to-r from-blue-50 via-indigo-50/60 to-slate-100 border-b border-slate-200/80 relative">
          <div className="absolute inset-0 opacity-40 bg-[radial-gradient(#3b82f6_1px,transparent_1px)] [background-size:20px_20px]" />
          {!isOwnProfile && (
            <button
              onClick={() => setViewingProfileId(currentUser.id)}
              className="absolute top-4 left-4 px-3.5 py-1.5 rounded-xl bg-white/95 backdrop-blur-sm text-xs font-semibold text-slate-700 border border-slate-200 hover:bg-white shadow-xs transition-colors"
            >
              ← Back to My Profile
            </button>
          )}
        </div>

        {/* Profile Main Info */}
        <div className="px-6 sm:px-8 pb-8 relative">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between -mt-14 sm:-mt-16 gap-4 mb-6">
            <div className="flex flex-col sm:flex-row sm:items-end gap-5">
              <div className="relative shrink-0">
                <img
                  src={profile.avatar_url}
                  alt={profile.full_name}
                  className="w-28 h-28 sm:w-32 sm:h-32 rounded-3xl object-cover ring-4 ring-white shadow-md bg-white"
                />
                <span className="absolute bottom-1 right-1 w-5 h-5 rounded-full bg-emerald-500 ring-2 ring-white" title="Active Student" />
              </div>

              <div className="pt-2 sm:pt-14">
                <div className="flex items-center gap-2.5 flex-wrap">
                  <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
                    {profile.full_name}
                  </h1>
                  <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-blue-50 text-blue-700 border border-blue-200">
                    Class of &apos;{profile.grad_year}
                  </span>
                </div>
                <p className="text-sm font-medium text-slate-500 mt-0.5">
                  @{profile.username} · {profile.major}
                </p>
                <p className="text-sm font-bold text-blue-600 mt-0.5">
                  {profile.university}
                </p>

                {/* Quick Badges Preview */}
                <div className="mt-2.5">
                  <BadgeSystem studentId={profile.id} variant="compact" maxDisplay={3} />
                </div>
              </div>
            </div>

            {/* Profile Action Buttons */}
            <div className="flex items-center gap-2 sm:mb-2">
              {isOwnProfile ? (
                <button
                  onClick={() => setIsEditOpen(true)}
                  className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold shadow-xs hover:shadow-sm transition-all"
                >
                  <Edit3 className="w-3.5 h-3.5" />
                  Edit Profile
                </button>
              ) : (
                <div className="flex items-center gap-2">
                  <a
                    href={`mailto:${profile.contact_email || 'student@university.edu'}`}
                    className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold shadow-xs transition-all"
                  >
                    Send Message
                  </a>
                </div>
              )}
            </div>
          </div>

          {/* Bio */}
          <div className="max-w-3xl">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1.5">
              About &amp; Research Focus
            </h3>
            <p className="text-sm text-slate-700 leading-relaxed whitespace-pre-line">
              {profile.bio || 'No bio provided yet.'}
            </p>
          </div>

          {/* Social Links */}
          <div className="flex items-center gap-4 mt-5 pt-4 border-t border-slate-100 flex-wrap">
            {profile.github_url && (
              <a
                href={profile.github_url}
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-1.5 text-xs font-medium text-slate-600 hover:text-blue-600 transition-colors"
              >
                <ExternalLink className="w-3.5 h-3.5" />
                GitHub
              </a>
            )}
            {profile.linkedin_url && (
              <a
                href={profile.linkedin_url}
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-1.5 text-xs font-medium text-slate-600 hover:text-blue-600 transition-colors"
              >
                <ExternalLink className="w-3.5 h-3.5" />
                LinkedIn
              </a>
            )}
            {profile.portfolio_url && (
              <a
                href={profile.portfolio_url}
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-1.5 text-xs font-medium text-slate-600 hover:text-blue-600 transition-colors"
              >
                <ExternalLink className="w-3.5 h-3.5" />
                Portfolio
              </a>
            )}
          </div>
        </div>
      </div>

      {/* Grid: Skills Showcase & Growth / Private Weaknesses */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: Badges & Skills Catalogue & Endorsements (8 cols) */}
        <div className="lg:col-span-8 space-y-6">
          {/* Earned Badges & Academic Milestones Component */}
          <BadgeSystem studentId={profile.id} variant="full" />

          {/* Skills Showcase Section */}
          <div className="bg-white border border-slate-200/90 rounded-3xl p-6 shadow-xs">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                  <Award className="w-5 h-5 text-blue-600" />
                  Verified Skills &amp; Peer Endorsements
                </h2>
                <p className="text-xs text-slate-500">
                  Relational skill mapping from the Supabase profile_skills table
                </p>
              </div>

              {isOwnProfile && (
                <button
                  onClick={() => setIsAddSkillOpen(true)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-blue-50 hover:bg-blue-100 text-blue-700 text-xs font-semibold border border-blue-200 transition-colors"
                >
                  <Plus className="w-3.5 h-3.5" />
                  Add Skill
                </button>
              )}
            </div>

            {/* Proficient Skills */}
            <div className="mb-6">
              <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-3 flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-500" />
                Proficient ({proficientSkills.length})
              </h3>
              {proficientSkills.length === 0 ? (
                <p className="text-xs text-slate-400 italic">No proficient skills listed yet.</p>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {proficientSkills.map((ps) => {
                    const hasEndorsed = ps.endorsed_by?.includes(currentUser.id);
                    return (
                      <div
                        key={ps.id}
                        className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200/80 flex items-center justify-between gap-3 group hover:border-blue-300 transition-colors"
                      >
                        <div>
                          <p className="font-semibold text-sm text-slate-900">
                            {ps.skill?.name || 'Skill'}
                          </p>
                          <p className="text-[10px] text-slate-500">{ps.skill?.category}</p>
                        </div>

                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => handleEndorse(ps.id)}
                            disabled={isOwnProfile}
                            className={`flex items-center gap-1 px-2.5 py-1 rounded-xl text-xs font-semibold transition-all ${
                              hasEndorsed
                                ? 'bg-blue-600 text-white'
                                : isOwnProfile
                                ? 'bg-slate-200 text-slate-700 cursor-default'
                                : 'bg-slate-200 hover:bg-blue-100 text-slate-700 hover:text-blue-700'
                            }`}
                            title={isOwnProfile ? 'Your skill' : 'Endorse peer skill'}
                          >
                            <ThumbsUp className="w-3 h-3" />
                            <span>{ps.endorsements_count}</span>
                          </button>

                          {isOwnProfile && (
                            <button
                              onClick={() => removeSkill(ps.skill_id)}
                              className="opacity-0 group-hover:opacity-100 p-1 text-slate-400 hover:text-red-600 rounded transition-opacity"
                              title="Remove skill"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Currently Learning Skills */}
            <div className="mb-6 pt-5 border-t border-slate-100">
              <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-3 flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-amber-500" />
                Currently Learning ({learningSkills.length})
              </h3>
              {learningSkills.length === 0 ? (
                <p className="text-xs text-slate-400 italic">No in-progress skills currently.</p>
              ) : (
                <div className="flex flex-wrap gap-2">
                  {learningSkills.map((ps) => (
                    <span
                      key={ps.id}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium bg-amber-50 text-amber-800 border border-amber-200"
                    >
                      <BookOpen className="w-3.5 h-3.5 text-amber-600" />
                      {ps.skill?.name}
                      {isOwnProfile && (
                        <button
                          onClick={() => removeSkill(ps.skill_id)}
                          className="hover:text-red-600 ml-1 font-bold"
                        >
                          ×
                        </button>
                      )}
                    </span>
                  ))}
                </div>
              )}
            </div>

            {/* Want to Learn Skills */}
            <div className="pt-5 border-t border-slate-100">
              <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-3 flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-blue-500" />
                Want to Learn ({wantToLearnSkills.length})
              </h3>
              {wantToLearnSkills.length === 0 ? (
                <p className="text-xs text-slate-400 italic">No target learning skills added yet.</p>
              ) : (
                <div className="flex flex-wrap gap-2">
                  {wantToLearnSkills.map((ps) => (
                    <span
                      key={ps.id}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium bg-blue-50 text-blue-800 border border-blue-200"
                    >
                      <Target className="w-3.5 h-3.5 text-blue-600" />
                      {ps.skill?.name}
                      {isOwnProfile && (
                        <button
                          onClick={() => removeSkill(ps.skill_id)}
                          className="hover:text-red-600 ml-1 font-bold"
                        >
                          ×
                        </button>
                      )}
                    </span>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Student's Posts Section */}
          <div className="space-y-4">
            <h3 className="font-bold text-slate-900 text-base">
              Recent Campus Posts by {profile.full_name}
            </h3>
            {studentPosts.length === 0 ? (
              <div className="bg-white border border-slate-200 rounded-2xl p-8 text-center text-xs text-slate-500">
                This student has not published any posts yet.
              </div>
            ) : (
              studentPosts.map((post) => <PostCard key={post.id} post={post} />)
            )}
          </div>
        </div>

        {/* Right Column: Learning Goals & Private Weaknesses (4 cols) */}
        <div className="lg:col-span-4 space-y-6">
          {/* Public Learning Goals Card */}
          <div className="bg-white border border-slate-200/90 rounded-3xl p-6 shadow-xs">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
                <Target className="w-4 h-4 text-blue-600" />
                Active Learning Goals
              </h3>
              {isOwnProfile && (
                <button
                  onClick={() => setIsEditOpen(true)}
                  className="text-xs text-blue-600 hover:underline font-medium"
                >
                  Edit
                </button>
              )}
            </div>
            <p className="text-xs text-slate-500 mb-3">
              Technologies and concepts {profile.full_name.split(' ')[0]} is actively exploring this semester:
            </p>
            <div className="space-y-2">
              {(profile.learning_goals || []).map((goal, idx) => (
                <div
                  key={idx}
                  className="p-3 rounded-xl bg-slate-50 border border-slate-200/80 flex items-center gap-2.5 text-xs font-medium text-slate-800"
                >
                  <span className="w-1.5 h-1.5 rounded-full bg-blue-600 shrink-0" />
                  <span>{goal}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Private Weaknesses Card (RLS Security Demo) */}
          <div className="bg-white border border-slate-200/90 rounded-3xl p-6 shadow-xs">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Shield className="w-4 h-4 text-amber-600" />
                <h3 className="font-bold text-slate-900 text-sm">
                  Private Growth &amp; Weaknesses
                </h3>
              </div>
              <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md bg-amber-50 text-amber-800 border border-amber-200">
                RLS Guarded
              </span>
            </div>

            {isOwnProfile ? (
              <div className="space-y-3">
                <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-[11px] text-emerald-800 flex items-start gap-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold">Visible only to you:</span> Supabase PostgreSQL policy ensures other users or public queries cannot select this column.
                  </div>
                </div>

                <div className="p-3.5 rounded-2xl bg-amber-50/50 border border-amber-200/70 text-xs text-slate-800 leading-relaxed italic">
                  &ldquo;{profile.private_weaknesses || 'No private weaknesses entered. Add notes on what you want to improve on!'}&rdquo;
                </div>

                <button
                  onClick={() => setIsEditOpen(true)}
                  className="w-full py-2 text-xs font-semibold text-slate-600 hover:text-blue-600 transition-colors"
                >
                  Edit Growth Notes
                </button>
              </div>
            ) : (
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 text-center space-y-2">
                <div className="w-8 h-8 rounded-full bg-slate-200 mx-auto flex items-center justify-center text-slate-500">
                  <Lock className="w-4 h-4" />
                </div>
                <p className="text-xs font-semibold text-slate-700">
                  Private Column Protected by RLS
                </p>
                <p className="text-[11px] text-slate-500 leading-relaxed">
                  Row Level Security (RLS) restricts access to the student author (<code className="font-mono text-[10px]">auth.uid() = id</code>). Other users cannot query this field.
                </p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Edit Profile Modal */}
      <EditProfileModal isOpen={isEditOpen} onClose={() => setIsEditOpen(false)} />

      {/* Add Skill Modal */}
      {isAddSkillOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in duration-150">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl w-full max-w-md p-6 shadow-2xl">
            <h3 className="font-bold text-base text-slate-900 dark:text-white mb-1">
              Add Skill to Your Profile
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mb-4">
              Choose from the verified SkillSphere catalogue
            </p>

            <form onSubmit={handleAddSkillSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1">
                  Select Skill
                </label>
                <select
                  value={selectedSkillId}
                  onChange={(e) => setSelectedSkillId(e.target.value)}
                  required
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="">-- Choose a skill --</option>
                  {availableSkillsToAdd.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name} ({s.category})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1">
                  Skill Status
                </label>
                <select
                  value={selectedStatus}
                  onChange={(e) => setSelectedStatus(e.target.value as SkillStatus)}
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="proficient">Proficient (Ready to build &amp; mentor)</option>
                  <option value="learning">Currently Learning</option>
                  <option value="want_to_learn">Want to Learn</option>
                </select>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setIsAddSkillOpen(false)}
                  className="px-3.5 py-2 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={!selectedSkillId}
                  className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white text-xs font-semibold shadow-sm"
                >
                  Add Skill
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
