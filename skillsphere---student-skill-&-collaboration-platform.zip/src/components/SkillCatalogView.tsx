import React, { useState } from 'react';
import { useSkillSphere } from '../services/store';
import { groupSkillsByCategory } from '../utils/pureLogic';
import { SkillStatus } from '../types';
import {
  Code2,
  Check,
  Plus,
  Users,
  Search,
  BookOpen,
  Target,
  Sparkles,
} from 'lucide-react';

export const SkillCatalogView: React.FC = () => {
  const {
    skills,
    profileSkills,
    currentUser,
    addOrUpdateSkill,
    removeSkill,
    setSelectedSkillFilter,
    setActiveView,
  } = useSkillSphere();

  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const mySkillsMap = new Map(
    profileSkills
      .filter((ps) => ps.profile_id === currentUser.id)
      .map((ps) => [ps.skill_id, ps.status])
  );

  const filteredSkills = skills.filter((skill) => {
    if (selectedCategory !== 'all' && skill.category !== selectedCategory) {
      return false;
    }
    if (search.trim()) {
      const q = search.toLowerCase();
      return (
        skill.name.toLowerCase().includes(q) ||
        skill.description.toLowerCase().includes(q) ||
        skill.category.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const categories = ['all', 'Web Development', 'AI & Machine Learning', 'Systems & Cloud', 'UI/UX Design', 'Data Science'];

  const handleStatusChange = (skillId: string, status: SkillStatus | 'remove') => {
    if (status === 'remove') {
      removeSkill(skillId);
    } else {
      addOrUpdateSkill(skillId, status);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div className="bg-white border border-slate-200/90 rounded-3xl p-6 sm:p-8 shadow-xs">
        <div className="max-w-3xl">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-blue-50 text-blue-700 border border-blue-200 mb-3">
            <Code2 className="w-3.5 h-3.5 text-blue-600" />
            Reusable Technical Catalogue
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            SkillSphere Verified Skills Directory
          </h1>
          <p className="text-sm text-slate-600 mt-2 leading-relaxed">
            A standardized taxonomy of technical disciplines and tools. Add skills to your profile, endorse your peers, or find students who master these technologies.
          </p>
        </div>

        {/* Search & Category Filter */}
        <div className="mt-6 pt-6 border-t border-slate-100 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          <div className="relative flex-1 max-w-md">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search skills (e.g. Next.js, PyTorch, Supabase)..."
              className="w-full bg-slate-100/80 border border-slate-200 rounded-xl pl-10 pr-4 py-2 text-xs sm:text-sm text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 focus:bg-white"
            />
          </div>

          <div className="flex items-center gap-1 overflow-x-auto pb-1 sm:pb-0">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors ${
                  selectedCategory === cat
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                {cat === 'all' ? 'All Categories' : cat}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Skills Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredSkills.map((skill) => {
          const myStatus = mySkillsMap.get(skill.id);
          const studentCount = profileSkills.filter(
            (ps) => ps.skill_id === skill.id && ps.status === 'proficient'
          ).length;

          return (
            <div
              key={skill.id}
              className="bg-white border border-slate-200/90 rounded-3xl p-6 shadow-xs hover:shadow-md transition-all flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between gap-3 mb-2">
                  <h3 className="font-bold text-base text-slate-900">
                    {skill.name}
                  </h3>
                  <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-md bg-slate-100 text-slate-700 border border-slate-200/60">
                    {skill.category}
                  </span>
                </div>

                <p className="text-xs text-slate-600 leading-relaxed mb-4">
                  {skill.description}
                </p>

                <div className="flex items-center justify-between text-xs text-slate-500 mb-4 pb-3 border-b border-slate-100">
                  <span className="flex items-center gap-1 text-slate-700 font-medium">
                    <Users className="w-3.5 h-3.5 text-blue-600" />
                    <strong>{studentCount}</strong> campus students proficient
                  </span>
                  <button
                    onClick={() => {
                      setSelectedSkillFilter(skill.name);
                      setActiveView('collaborators');
                    }}
                    className="text-blue-600 hover:underline text-xs font-medium"
                  >
                    View Students →
                  </button>
                </div>
              </div>

              {/* Status Action */}
              <div>
                <span className="text-[11px] font-semibold text-slate-500 block mb-1.5">
                  Your Profile Status:
                </span>
                <div className="grid grid-cols-3 gap-1.5 text-xs">
                  <button
                    onClick={() =>
                      handleStatusChange(skill.id, myStatus === 'proficient' ? 'remove' : 'proficient')
                    }
                    className={`py-1.5 px-2 rounded-xl font-medium border text-center transition-all ${
                      myStatus === 'proficient'
                        ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                        : 'border-slate-200 text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    {myStatus === 'proficient' ? '✓ Proficient' : 'Proficient'}
                  </button>

                  <button
                    onClick={() =>
                      handleStatusChange(skill.id, myStatus === 'learning' ? 'remove' : 'learning')
                    }
                    className={`py-1.5 px-2 rounded-xl font-medium border text-center transition-all ${
                      myStatus === 'learning'
                        ? 'bg-amber-600 text-white border-amber-600 shadow-xs'
                        : 'border-slate-200 text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    {myStatus === 'learning' ? '✓ Learning' : 'Learning'}
                  </button>

                  <button
                    onClick={() =>
                      handleStatusChange(skill.id, myStatus === 'want_to_learn' ? 'remove' : 'want_to_learn')
                    }
                    className={`py-1.5 px-2 rounded-xl font-medium border text-center transition-all ${
                      myStatus === 'want_to_learn'
                        ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                        : 'border-slate-200 text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    {myStatus === 'want_to_learn' ? '✓ Target' : 'Want to Learn'}
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
