import React, { useState } from 'react';
import { useSkillSphere } from '../services/store';
import { PostCard } from './PostCard';
import { BadgeSystem } from './BadgeSystem';
import { Post } from '../types';
import { filterPosts } from '../utils/pureLogic';
import {
  Users,
  Trophy,
  GitBranch,
  Sparkles,
  Search,
  Plus,
  ShieldCheck,
  TrendingUp,
  ArrowRight,
  Database,
} from 'lucide-react';

interface FeedViewProps {
  onOpenCreatePost: () => void;
  onOpenCollabModal: (post: Post) => void;
}

export const FeedView: React.FC<FeedViewProps> = ({
  onOpenCreatePost,
  onOpenCollabModal,
}) => {
  const {
    currentUser,
    posts,
    searchQuery,
    setSearchQuery,
    profileSkills,
    skills,
    setActiveView,
    setViewingProfileId,
    setSelectedSkillFilter,
  } = useSkillSphere();

  const [activeTab, setActiveTab] = useState<'all' | 'collaborator_request' | 'achievement' | 'project_update'>('all');

  const filteredPosts = filterPosts(posts, activeTab, searchQuery);

  const mySkills = profileSkills.filter((ps) => ps.profile_id === currentUser.id);
  const proficientSkills = mySkills.filter((ps) => ps.status === 'proficient');

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: Feed (8 cols on desktop) */}
        <div className="lg:col-span-8 space-y-6">
          {/* Quick Share Card */}
          <div className="bg-white border border-slate-200/90 rounded-2xl p-4 sm:p-5 shadow-xs">
            <div className="flex items-center gap-3">
              <button
                onClick={() => {
                  setViewingProfileId(currentUser.id);
                  setActiveView('profile');
                }}
                className="focus:outline-none"
              >
                <img
                  src={currentUser.avatar_url}
                  alt={currentUser.full_name}
                  className="w-10 h-10 rounded-full object-cover ring-2 ring-blue-500/20 hover:ring-blue-500 transition-all"
                />
              </button>
              <button
                onClick={onOpenCreatePost}
                className="flex-1 bg-slate-100/80 hover:bg-slate-100 text-left px-4 py-2.5 rounded-xl text-xs sm:text-sm text-slate-600 transition-colors border border-transparent hover:border-slate-200"
              >
                Hey {currentUser.full_name.split(' ')[0]}, looking for collaborators or sharing an achievement?
              </button>
              <button
                onClick={onOpenCreatePost}
                className="p-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white shadow-xs shrink-0 transition-all"
                title="Create Post"
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>

            <div className="flex items-center justify-between gap-2 mt-4 pt-3 border-t border-slate-100">
              <button
                onClick={onOpenCreatePost}
                className="flex-1 flex items-center justify-center gap-1.5 py-1.5 px-2 rounded-lg text-xs font-semibold text-blue-700 hover:bg-blue-50 transition-colors"
              >
                <Users className="w-3.5 h-3.5 text-blue-600" />
                Find Collaborator
              </button>
              <button
                onClick={onOpenCreatePost}
                className="flex-1 flex items-center justify-center gap-1.5 py-1.5 px-2 rounded-lg text-xs font-semibold text-amber-700 hover:bg-amber-50 transition-colors"
              >
                <Trophy className="w-3.5 h-3.5 text-amber-600" />
                Share Achievement
              </button>
              <button
                onClick={onOpenCreatePost}
                className="flex-1 flex items-center justify-center gap-1.5 py-1.5 px-2 rounded-lg text-xs font-semibold text-emerald-700 hover:bg-emerald-50 transition-colors"
              >
                <GitBranch className="w-3.5 h-3.5 text-emerald-600" />
                Project Milestone
              </button>
            </div>
          </div>

          {/* Filter Bar & Search Notice */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-white border border-slate-200/90 rounded-2xl p-2.5 shadow-xs">
            <div className="flex items-center gap-1 overflow-x-auto pb-1 sm:pb-0">
              <button
                onClick={() => setActiveTab('all')}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                  activeTab === 'all'
                    ? 'bg-slate-900 text-white shadow-xs'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                All Posts ({posts.length})
              </button>
              <button
                onClick={() => setActiveTab('collaborator_request')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                  activeTab === 'collaborator_request'
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                <Users className="w-3.5 h-3.5" />
                Collaborator Calls
              </button>
              <button
                onClick={() => setActiveTab('achievement')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                  activeTab === 'achievement'
                    ? 'bg-amber-600 text-white shadow-xs'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                <Trophy className="w-3.5 h-3.5" />
                Achievements
              </button>
              <button
                onClick={() => setActiveTab('project_update')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                  activeTab === 'project_update'
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                <GitBranch className="w-3.5 h-3.5" />
                Milestones
              </button>
            </div>

            {searchQuery && (
              <div className="flex items-center gap-2 px-2.5 py-1 rounded-lg bg-blue-50 border border-blue-200 text-xs text-blue-700">
                <Search className="w-3.5 h-3.5" />
                <span>Filter: &quot;{searchQuery}&quot;</span>
                <button
                  onClick={() => setSearchQuery('')}
                  className="hover:text-blue-900 font-bold ml-1"
                >
                  ×
                </button>
              </div>
            )}
          </div>

          {/* Posts Feed */}
          {filteredPosts.length === 0 ? (
            <div className="bg-white border border-slate-200 rounded-2xl p-12 text-center shadow-xs">
              <Sparkles className="w-10 h-10 text-slate-300 mx-auto mb-3" />
              <h3 className="text-base font-semibold text-slate-800">
                No posts match this filter
              </h3>
              <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
                Try searching another skill or be the first to publish a collaboration request!
              </p>
              <button
                onClick={onOpenCreatePost}
                className="mt-4 px-4 py-2 rounded-xl bg-blue-600 text-white text-xs font-semibold shadow-xs hover:bg-blue-700"
              >
                Post Something Now
              </button>
            </div>
          ) : (
            <div className="space-y-5">
              {filteredPosts.map((post) => (
                <PostCard
                  key={post.id}
                  post={post}
                  onOpenCollabModal={onOpenCollabModal}
                />
              ))}
            </div>
          )}
        </div>

        {/* Right Column: Campus Sidebar (4 cols on desktop) */}
        <div className="lg:col-span-4 space-y-6">
          {/* Student Profile Snapshot */}
          <div className="bg-white border border-slate-200/90 rounded-2xl p-5 shadow-xs">
            <div className="flex items-center gap-3">
              <img
                src={currentUser.avatar_url}
                alt={currentUser.full_name}
                className="w-12 h-12 rounded-full object-cover ring-2 ring-blue-500/20"
              />
              <div className="truncate">
                <h4 className="font-bold text-slate-900 text-sm truncate">
                  {currentUser.full_name}
                </h4>
                <p className="text-xs text-blue-600 font-semibold truncate">
                  {currentUser.university}
                </p>
                <p className="text-xs text-slate-500 truncate">{currentUser.major} &apos;{String(currentUser.grad_year).slice(-2)}</p>
              </div>
            </div>

            <p className="mt-3 text-xs text-slate-600 line-clamp-2 leading-relaxed">
              {currentUser.bio}
            </p>

            {/* Earned Badges Snapshot */}
            <div className="mt-3 pt-3 border-t border-slate-100">
              <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block mb-1.5 flex items-center gap-1">
                <Trophy className="w-3 h-3 text-amber-500" />
                Earned Badges
              </span>
              <BadgeSystem studentId={currentUser.id} variant="compact" maxDisplay={2} />
            </div>

            {/* Verified Skills snippet */}
            <div className="mt-3 pt-3 border-t border-slate-100">
              <div className="flex items-center justify-between text-xs mb-2">
                <span className="font-semibold text-slate-700">
                  Proficient Skills ({proficientSkills.length})
                </span>
                <button
                  onClick={() => {
                    setViewingProfileId(currentUser.id);
                    setActiveView('profile');
                  }}
                  className="text-blue-600 hover:underline text-[11px] font-medium"
                >
                  Manage
                </button>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {proficientSkills.slice(0, 5).map((ps) => (
                  <span
                    key={ps.id}
                    className="px-2 py-0.5 rounded-md text-[11px] font-medium bg-slate-100 text-slate-700 border border-slate-200/60"
                  >
                    {ps.skill?.name || 'Skill'}
                  </span>
                ))}
              </div>
            </div>

            <button
              onClick={() => {
                setViewingProfileId(currentUser.id);
                setActiveView('profile');
              }}
              className="mt-4 w-full py-2 px-3 rounded-xl border border-slate-200 text-slate-700 text-xs font-semibold hover:bg-slate-50 transition-colors flex items-center justify-center gap-1.5"
            >
              View Full Profile Dashboard
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Trending Campus Skills */}
          <div className="bg-white border border-slate-200/90 rounded-2xl p-5 shadow-xs">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-1.5 font-bold text-sm text-slate-900">
                <TrendingUp className="w-4 h-4 text-blue-600" />
                <span>Trending Campus Skills</span>
              </div>
              <button
                onClick={() => setActiveView('skills')}
                className="text-xs text-blue-600 hover:underline font-medium"
              >
                Catalogue
              </button>
            </div>
            <p className="text-xs text-slate-500 mb-3">
              Most requested by student founders and hackathon teams this week:
            </p>
            <div className="space-y-1.5">
              {skills.slice(0, 5).map((skill, index) => (
                <button
                  key={skill.id}
                  onClick={() => {
                    setSelectedSkillFilter(skill.name);
                    setActiveView('collaborators');
                  }}
                  className="w-full flex items-center justify-between p-2 rounded-xl hover:bg-slate-50 text-left transition-colors group"
                >
                  <div className="flex items-center gap-2 truncate">
                    <span className="w-5 text-center text-xs font-bold text-slate-400 group-hover:text-blue-600">
                      #{index + 1}
                    </span>
                    <div>
                      <p className="text-xs font-semibold text-slate-800 group-hover:text-blue-600">
                        {skill.name}
                      </p>
                      <p className="text-[10px] text-slate-400">{skill.category}</p>
                    </div>
                  </div>
                  <span className="text-[11px] font-medium text-slate-600 bg-slate-100 px-2 py-0.5 rounded-full shrink-0 border border-slate-200/60">
                    {skill.verified_count} verified
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* Supabase PostgreSQL & RLS Architecture card (Clean Light Theme) */}
          <div className="bg-gradient-to-br from-blue-50/70 via-indigo-50/30 to-white border border-blue-200/70 rounded-2xl p-5 shadow-xs text-slate-900">
            <div className="flex items-center gap-2.5 mb-2">
              <div className="w-8 h-8 rounded-lg bg-blue-600 text-white flex items-center justify-center shadow-xs">
                <Database className="w-4 h-4" />
              </div>
              <div>
                <h4 className="font-bold text-sm text-slate-900">Supabase PostgreSQL &amp; RLS</h4>
                <p className="text-[11px] text-blue-700 font-semibold">Production-Ready Relational Schema</p>
              </div>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed mt-2">
              Configured with 6 relational tables, UUID keys, cascade foreign keys, and Row Level Security policies protecting student private weaknesses and contact data.
            </p>
            <div className="mt-3.5 flex items-center gap-2">
              <div className="flex items-center gap-1 text-[11px] text-slate-600 font-medium">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                <span>RLS Active</span>
              </div>
              <span className="text-slate-300">•</span>
              <span className="text-[11px] text-slate-600">auth.uid() Verified</span>
            </div>
            <button
              onClick={() => setActiveView('sql_schema')}
              className="mt-4 w-full py-2 px-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold transition-all flex items-center justify-center gap-1.5 shadow-xs"
            >
              Inspect SQL Schema Script
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
