import React, { useState } from 'react';
import { SUPABASE_SQL_SCRIPT } from '../data/sqlScript';
import { useSkillSphere } from '../services/store';
import {
  Database,
  Copy,
  Check,
  Download,
  ShieldCheck,
  Table,
  Key,
  Layers,
  Sparkles,
  Link2,
  ExternalLink,
} from 'lucide-react';

export const SqlSchemaViewer: React.FC = () => {
  const { supabaseConfig, saveSupabaseConfig } = useSkillSphere();

  const [copied, setCopied] = useState(false);
  const [activeTab, setActiveTab] = useState<'sql' | 'architecture' | 'rls_matrix' | 'connection'>('sql');

  // Supabase connection form state
  const [inputUrl, setInputUrl] = useState(supabaseConfig.supabaseUrl || '');
  const [inputKey, setInputKey] = useState(supabaseConfig.supabaseAnonKey || '');
  const [statusMessage, setStatusMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [isTesting, setIsTesting] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(SUPABASE_SQL_SCRIPT);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const blob = new Blob([SUPABASE_SQL_SCRIPT], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'skillsphere_supabase_schema.sql';
    link.click();
    URL.revokeObjectURL(url);
  };

  const handleSaveConnection = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsTesting(true);
    setStatusMessage(null);

    const res = await saveSupabaseConfig(inputUrl.trim(), inputKey.trim());
    setIsTesting(false);

    if (res.success) {
      setStatusMessage({
        type: 'success',
        text: inputUrl ? 'Successfully connected to your live Supabase project!' : 'Reset to local demo database.',
      });
    } else {
      setStatusMessage({
        type: 'error',
        text: res.error || 'Failed to connect. Check your Supabase URL and Anon Key.',
      });
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div className="bg-white border border-slate-200/90 rounded-3xl p-6 sm:p-8 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200 mb-2">
              <Database className="w-3.5 h-3.5 text-emerald-600" />
              Supabase PostgreSQL Architecture &amp; RLS
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
              Production Database Schema &amp; Security Script
            </h1>
            <p className="text-sm text-slate-600 mt-1">
              Complete PostgreSQL DDL, Row Level Security policies, cascade constraints, and auto-provisioning triggers.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleCopy}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200/80 text-slate-800 text-xs font-semibold border border-slate-200 transition-colors"
            >
              {copied ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4 text-slate-600" />}
              <span>{copied ? 'SQL Copied!' : 'Copy SQL Script'}</span>
            </button>

            <button
              onClick={handleDownload}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold shadow-xs transition-all"
            >
              <Download className="w-4 h-4" />
              <span>Download .sql</span>
            </button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center gap-2 mt-6 pt-6 border-t border-slate-100 overflow-x-auto">
          <button
            onClick={() => setActiveTab('sql')}
            className={`px-4 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors ${
              activeTab === 'sql'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            PostgreSQL Script (DDL &amp; Policies)
          </button>
          <button
            onClick={() => setActiveTab('architecture')}
            className={`px-4 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors ${
              activeTab === 'architecture'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            Relational Table Schema (6 Tables)
          </button>
          <button
            onClick={() => setActiveTab('rls_matrix')}
            className={`px-4 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors ${
              activeTab === 'rls_matrix'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            Row Level Security (RLS) Matrix
          </button>
          <button
            onClick={() => setActiveTab('connection')}
            className={`px-4 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors ${
              activeTab === 'connection'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            Connect Custom Supabase Project
          </button>
        </div>
      </div>

      {/* Tab: SQL Script (Clean Light Code Viewer) */}
      {activeTab === 'sql' && (
        <div className="bg-slate-50 border border-slate-200/90 rounded-3xl p-6 shadow-xs overflow-hidden text-slate-800">
          <div className="flex items-center justify-between pb-4 mb-4 border-b border-slate-200">
            <div className="flex items-center gap-2 text-xs text-slate-500">
              <span className="w-3 h-3 rounded-full bg-slate-300 inline-block" />
              <span className="w-3 h-3 rounded-full bg-slate-300 inline-block" />
              <span className="w-3 h-3 rounded-full bg-slate-300 inline-block" />
              <span className="font-mono text-slate-600 font-semibold ml-2">supabase/schema.sql</span>
            </div>
            <button
              onClick={handleCopy}
              className="text-xs font-semibold text-blue-700 hover:text-blue-800 bg-white border border-slate-200 px-3 py-1 rounded-lg flex items-center gap-1 shadow-2xs"
            >
              <Copy className="w-3.5 h-3.5" />
              {copied ? 'Copied' : 'Copy SQL'}
            </button>
          </div>
          <pre className="font-mono text-xs sm:text-[13px] leading-relaxed text-slate-800 overflow-x-auto max-h-[600px] p-3 select-all bg-white rounded-2xl border border-slate-200/70">
            {SUPABASE_SQL_SCRIPT}
          </pre>
        </div>
      )}

      {/* Tab: Relational Table Schema */}
      {activeTab === 'architecture' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {/* Profiles */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                <Table className="w-4 h-4 text-indigo-500" />
                public.profiles
              </h3>
              <span className="text-[10px] font-mono bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 px-2 py-0.5 rounded">
                auth.users 1:1
              </span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Extends user records with public university details and RLS-protected private weaknesses.
            </p>
            <ul className="text-xs font-mono space-y-1 text-slate-700 dark:text-slate-300">
              <li><strong className="text-indigo-500">id</strong>: UUID (PK, FK auth.users)</li>
              <li><strong>username</strong>: TEXT UNIQUE</li>
              <li><strong>full_name</strong>: TEXT</li>
              <li><strong>university, major, grad_year</strong></li>
              <li><strong>bio</strong>: TEXT</li>
              <li><strong>learning_goals</strong>: TEXT[]</li>
              <li className="text-amber-500">🔒 <strong>private_weaknesses</strong> (RLS private)</li>
              <li className="text-amber-500">🔒 <strong>contact_email</strong> (RLS private)</li>
            </ul>
          </div>

          {/* Skills */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                <Table className="w-4 h-4 text-emerald-500" />
                public.skills
              </h3>
              <span className="text-[10px] font-mono bg-emerald-50 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 px-2 py-0.5 rounded">
                Reusable Catalogue
              </span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Shared catalogue of student skills categorized into Web, AI/ML, Systems, Design, and Data.
            </p>
            <ul className="text-xs font-mono space-y-1 text-slate-700 dark:text-slate-300">
              <li><strong className="text-emerald-500">id</strong>: UUID (PK gen_random_uuid())</li>
              <li><strong>name</strong>: TEXT UNIQUE NOT NULL</li>
              <li><strong>category</strong>: TEXT CHECK</li>
              <li><strong>description</strong>: TEXT</li>
              <li><strong>verified_count</strong>: INT DEFAULT 0</li>
              <li><strong>created_at</strong>: TIMESTAMPTZ</li>
            </ul>
          </div>

          {/* Profile Skills */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                <Table className="w-4 h-4 text-cyan-500" />
                public.profile_skills
              </h3>
              <span className="text-[10px] font-mono bg-cyan-50 dark:bg-cyan-950 text-cyan-600 dark:text-cyan-400 px-2 py-0.5 rounded">
                M:N Link Table
              </span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Maps students to skills with status (&apos;proficient&apos; | &apos;learning&apos; | &apos;want_to_learn&apos;) and endorsements.
            </p>
            <ul className="text-xs font-mono space-y-1 text-slate-700 dark:text-slate-300">
              <li><strong className="text-cyan-500">id</strong>: UUID (PK)</li>
              <li><strong>profile_id</strong>: UUID (FK profiles CASCADE)</li>
              <li><strong>skill_id</strong>: UUID (FK skills CASCADE)</li>
              <li><strong>status</strong>: CHECK in status types</li>
              <li><strong>endorsements_count</strong>: INT &gt;= 0</li>
              <li><strong>UNIQUE(profile_id, skill_id)</strong></li>
            </ul>
          </div>

          {/* Posts */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                <Table className="w-4 h-4 text-purple-500" />
                public.posts
              </h3>
              <span className="text-[10px] font-mono bg-purple-50 dark:bg-purple-950 text-purple-600 dark:text-purple-400 px-2 py-0.5 rounded">
                Feed Posts
              </span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Social timeline for collaborator requests, hackathon achievements, and project updates.
            </p>
            <ul className="text-xs font-mono space-y-1 text-slate-700 dark:text-slate-300">
              <li><strong className="text-purple-500">id</strong>: UUID (PK)</li>
              <li><strong>author_id</strong>: UUID (FK profiles CASCADE)</li>
              <li><strong>post_type</strong>: collaborator_request, etc.</li>
              <li><strong>text_content</strong>: TEXT NOT NULL</li>
              <li><strong>image_path</strong>: TEXT (Supabase storage)</li>
              <li><strong>looking_for_skills</strong>: TEXT[]</li>
            </ul>
          </div>

          {/* Likes */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                <Table className="w-4 h-4 text-rose-500" />
                public.likes
              </h3>
              <span className="text-[10px] font-mono bg-rose-50 dark:bg-rose-950 text-rose-600 dark:text-rose-400 px-2 py-0.5 rounded">
                Unique Pair
              </span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Unique student post likes. Guaranteed idempotency with composite unique constraint.
            </p>
            <ul className="text-xs font-mono space-y-1 text-slate-700 dark:text-slate-300">
              <li><strong className="text-rose-500">id</strong>: UUID (PK)</li>
              <li><strong>post_id</strong>: UUID (FK posts CASCADE)</li>
              <li><strong>user_id</strong>: UUID (FK profiles CASCADE)</li>
              <li><strong>UNIQUE(post_id, user_id)</strong></li>
            </ul>
          </div>

          {/* Comments */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                <Table className="w-4 h-4 text-amber-500" />
                public.comments
              </h3>
              <span className="text-[10px] font-mono bg-amber-50 dark:bg-amber-950 text-amber-600 dark:text-amber-400 px-2 py-0.5 rounded">
                Discussion Thread
              </span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Threaded student discussions on projects and collaboration requests.
            </p>
            <ul className="text-xs font-mono space-y-1 text-slate-700 dark:text-slate-300">
              <li><strong className="text-amber-500">id</strong>: UUID (PK)</li>
              <li><strong>post_id</strong>: UUID (FK posts CASCADE)</li>
              <li><strong>author_id</strong>: UUID (FK profiles CASCADE)</li>
              <li><strong>text_content</strong>: TEXT NOT NULL</li>
              <li><strong>created_at</strong>: TIMESTAMPTZ</li>
            </ul>
          </div>
        </div>
      )}

      {/* Tab: RLS Matrix */}
      {activeTab === 'rls_matrix' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl overflow-hidden shadow-sm">
          <div className="p-6 border-b border-slate-100 dark:border-slate-800">
            <h3 className="font-bold text-base text-slate-900 dark:text-white flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-emerald-500" />
              Row Level Security (RLS) Policy Specifications
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              Enforced natively by the PostgreSQL kernel on every Supabase query.
            </p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-50 dark:bg-slate-800/60 text-slate-500 dark:text-slate-400 uppercase font-semibold border-b border-slate-200 dark:border-slate-700">
                <tr>
                  <th className="py-3 px-4">Table</th>
                  <th className="py-3 px-4">SELECT (Read)</th>
                  <th className="py-3 px-4">INSERT (Create)</th>
                  <th className="py-3 px-4">UPDATE (Modify)</th>
                  <th className="py-3 px-4">DELETE (Remove)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-mono">
                <tr>
                  <td className="py-3 px-4 font-bold text-slate-900 dark:text-white">profiles</td>
                  <td className="py-3 px-4 text-emerald-600">public_profiles view / true</td>
                  <td className="py-3 px-4 text-indigo-600">auth.uid() = id</td>
                  <td className="py-3 px-4 text-indigo-600">auth.uid() = id</td>
                  <td className="py-3 px-4 text-indigo-600">auth.uid() = id</td>
                </tr>
                <tr>
                  <td className="py-3 px-4 font-bold text-slate-900 dark:text-white">skills</td>
                  <td className="py-3 px-4 text-emerald-600">true (Public Read)</td>
                  <td className="py-3 px-4 text-indigo-600">auth.role() = &apos;authenticated&apos;</td>
                  <td className="py-3 px-4 text-slate-400">Admin Only</td>
                  <td className="py-3 px-4 text-slate-400">Admin Only</td>
                </tr>
                <tr>
                  <td className="py-3 px-4 font-bold text-slate-900 dark:text-white">profile_skills</td>
                  <td className="py-3 px-4 text-emerald-600">true (Public Read)</td>
                  <td className="py-3 px-4 text-indigo-600">auth.uid() = profile_id</td>
                  <td className="py-3 px-4 text-indigo-600">auth.uid() = profile_id</td>
                  <td className="py-3 px-4 text-indigo-600">auth.uid() = profile_id</td>
                </tr>
                <tr>
                  <td className="py-3 px-4 font-bold text-slate-900 dark:text-white">posts</td>
                  <td className="py-3 px-4 text-emerald-600">true (Public Feed)</td>
                  <td className="py-3 px-4 text-indigo-600">auth.uid() = author_id</td>
                  <td className="py-3 px-4 text-indigo-600">auth.uid() = author_id</td>
                  <td className="py-3 px-4 text-indigo-600">auth.uid() = author_id</td>
                </tr>
                <tr>
                  <td className="py-3 px-4 font-bold text-slate-900 dark:text-white">likes</td>
                  <td className="py-3 px-4 text-emerald-600">true (Public Read)</td>
                  <td className="py-3 px-4 text-indigo-600">auth.uid() = user_id</td>
                  <td className="py-3 px-4 text-slate-400">N/A</td>
                  <td className="py-3 px-4 text-indigo-600">auth.uid() = user_id</td>
                </tr>
                <tr>
                  <td className="py-3 px-4 font-bold text-slate-900 dark:text-white">comments</td>
                  <td className="py-3 px-4 text-emerald-600">true (Public Read)</td>
                  <td className="py-3 px-4 text-indigo-600">auth.uid() = author_id</td>
                  <td className="py-3 px-4 text-indigo-600">auth.uid() = author_id</td>
                  <td className="py-3 px-4 text-indigo-600">auth.uid() = author_id</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab: Supabase Connection Settings */}
      {activeTab === 'connection' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-8 shadow-sm max-w-2xl">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-2xl bg-emerald-500/10 text-emerald-500 flex items-center justify-center">
              <Link2 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base text-slate-900 dark:text-white">
                Live Supabase Backend Connector
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Connect your real Supabase project URL and public Anon Key
              </p>
            </div>
          </div>

          <form onSubmit={handleSaveConnection} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1">
                Supabase Project URL
              </label>
              <input
                type="url"
                value={inputUrl}
                onChange={(e) => setInputUrl(e.target.value)}
                placeholder="https://xyzcompany.supabase.co"
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3.5 py-2 text-xs text-slate-900 dark:text-slate-100 font-mono focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1">
                Supabase Anon / Public API Key
              </label>
              <input
                type="text"
                value={inputKey}
                onChange={(e) => setInputKey(e.target.value)}
                placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3.5 py-2 text-xs text-slate-900 dark:text-slate-100 font-mono focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>

            {statusMessage && (
              <div
                className={`p-3 rounded-xl text-xs font-medium ${
                  statusMessage.type === 'success'
                    ? 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800'
                    : 'bg-red-50 dark:bg-red-950/60 text-red-700 dark:text-red-300 border border-red-200 dark:border-red-800'
                }`}
              >
                {statusMessage.text}
              </div>
            )}

            <div className="flex items-center justify-between pt-2">
              <button
                type="button"
                onClick={() => {
                  setInputUrl('');
                  setInputKey('');
                  saveSupabaseConfig('', '');
                  setStatusMessage({ type: 'success', text: 'Reset to local high-fidelity demo database.' });
                }}
                className="text-xs text-slate-500 hover:text-slate-700 dark:hover:text-slate-300"
              >
                Clear &amp; Use Offline Demo DB
              </button>

              <button
                type="submit"
                disabled={isTesting}
                className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white text-xs font-semibold shadow-sm transition-all flex items-center gap-1.5"
              >
                {isTesting ? 'Verifying...' : 'Test & Save Connection'}
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
