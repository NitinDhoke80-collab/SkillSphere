import React, { useState } from 'react';
import { useSkillSphere } from '../services/store';
import { PostType } from '../types';
import { validatePostInput } from '../utils/pureLogic';
import {
  X,
  Users,
  Trophy,
  GitBranch,
  Sparkles,
  Image as ImageIcon,
  Check,
  AlertCircle,
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface CreatePostModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const SAMPLE_PROJECT_IMAGES = [
  {
    name: 'Hardware & Drone Robotics',
    url: 'https://images.unsplash.com/photo-1508614589041-895b88991e3e?w=800&auto=format&fit=crop&q=80',
  },
  {
    name: 'Design System & UI',
    url: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800&auto=format&fit=crop&q=80',
  },
  {
    name: 'AI Model & BioMed Lab',
    url: 'https://images.unsplash.com/photo-1507668077129-56e32842fceb?w=800&auto=format&fit=crop&q=80',
  },
  {
    name: 'Database & Server Infra',
    url: 'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?w=800&auto=format&fit=crop&q=80',
  },
];

export const CreatePostModal: React.FC<CreatePostModalProps> = ({ isOpen, onClose }) => {
  const { currentUser, createPost, skills } = useSkillSphere();

  const [postType, setPostType] = useState<PostType>('collaborator_request');
  const [textContent, setTextContent] = useState('');
  const [projectTitle, setProjectTitle] = useState('');
  const [projectRepo, setProjectRepo] = useState('');
  const [lookingForSkills, setLookingForSkills] = useState<string[]>([]);
  const [customSkillInput, setCustomSkillInput] = useState('');
  const [imagePath, setImagePath] = useState('');
  const [showImagePicker, setShowImagePicker] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  if (!isOpen) return null;

  const handleToggleSkill = (skillName: string) => {
    if (lookingForSkills.includes(skillName)) {
      setLookingForSkills(lookingForSkills.filter((s) => s !== skillName));
    } else {
      setLookingForSkills([...lookingForSkills, skillName]);
    }
  };

  const handleAddCustomSkill = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && customSkillInput.trim()) {
      e.preventDefault();
      if (!lookingForSkills.includes(customSkillInput.trim())) {
        setLookingForSkills([...lookingForSkills, customSkillInput.trim()]);
      }
      setCustomSkillInput('');
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const validation = validatePostInput(textContent, postType, projectTitle, lookingForSkills);
    if (!validation.isValid) {
      setErrorMessage(validation.error || 'Please fill required fields.');
      return;
    }

    createPost({
      post_type: postType,
      text_content: textContent.trim(),
      project_title: projectTitle.trim() || undefined,
      project_repo: projectRepo.trim() || undefined,
      looking_for_skills: postType === 'collaborator_request' ? lookingForSkills : [],
      image_path: imagePath.trim() || undefined,
    });

    if (postType === 'achievement') {
      confetti({
        particleCount: 40,
        spread: 70,
        origin: { y: 0.6 },
      });
    }

    onClose();
    // Reset fields
    setTextContent('');
    setProjectTitle('');
    setProjectRepo('');
    setLookingForSkills([]);
    setImagePath('');
    setErrorMessage('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="bg-white border border-slate-200 rounded-3xl w-full max-w-2xl max-h-[90vh] overflow-y-auto shadow-2xl">
        {/* Header */}
        <div className="p-5 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img
              src={currentUser.avatar_url}
              alt=""
              className="w-10 h-10 rounded-full object-cover ring-2 ring-blue-500/20"
            />
            <div>
              <h2 className="font-bold text-slate-900 text-base">
                Create Campus Post
              </h2>
              <p className="text-xs text-slate-500">
                Posting as {currentUser.full_name} · {currentUser.university}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-600 rounded-xl hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          {/* Post Type Selector */}
          <div>
            <label className="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-2">
              Post Category
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              <button
                type="button"
                onClick={() => setPostType('collaborator_request')}
                className={`p-2.5 rounded-xl border text-xs font-medium flex flex-col items-center gap-1.5 transition-all ${
                  postType === 'collaborator_request'
                    ? 'bg-blue-50 border-blue-500 text-blue-700 ring-2 ring-blue-500/20 font-semibold'
                    : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                }`}
              >
                <Users className="w-4 h-4 text-blue-600" />
                Find Collaborator
              </button>

              <button
                type="button"
                onClick={() => setPostType('achievement')}
                className={`p-2.5 rounded-xl border text-xs font-medium flex flex-col items-center gap-1.5 transition-all ${
                  postType === 'achievement'
                    ? 'bg-amber-50 border-amber-500 text-amber-800 ring-2 ring-amber-500/20 font-semibold'
                    : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                }`}
              >
                <Trophy className="w-4 h-4 text-amber-600" />
                Achievement
              </button>

              <button
                type="button"
                onClick={() => setPostType('project_update')}
                className={`p-2.5 rounded-xl border text-xs font-medium flex flex-col items-center gap-1.5 transition-all ${
                  postType === 'project_update'
                    ? 'bg-emerald-50 border-emerald-500 text-emerald-800 ring-2 ring-emerald-500/20 font-semibold'
                    : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                }`}
              >
                <GitBranch className="w-4 h-4 text-emerald-600" />
                Project Milestone
              </button>

              <button
                type="button"
                onClick={() => setPostType('general')}
                className={`p-2.5 rounded-xl border text-xs font-medium flex flex-col items-center gap-1.5 transition-all ${
                  postType === 'general'
                    ? 'bg-slate-100 border-slate-400 text-slate-900 ring-2 ring-slate-400/20 font-semibold'
                    : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                }`}
              >
                <Sparkles className="w-4 h-4 text-slate-500" />
                General Idea
              </button>
            </div>
          </div>

          {/* Collaborator / Project Fields */}
          {(postType === 'collaborator_request' || postType === 'project_update' || postType === 'achievement') && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-3.5 bg-slate-50 rounded-2xl border border-slate-200">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Project Title {postType === 'collaborator_request' && <span className="text-red-500">*</span>}
                </label>
                <input
                  type="text"
                  value={projectTitle}
                  onChange={(e) => setProjectTitle(e.target.value)}
                  placeholder="e.g. NeuroFlow EEG or AeroNav Drone"
                  className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  GitHub Repository / Demo Link
                </label>
                <input
                  type="text"
                  value={projectRepo}
                  onChange={(e) => setProjectRepo(e.target.value)}
                  placeholder="https://github.com/..."
                  className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                />
              </div>
            </div>
          )}

          {/* Looking for Skills (Collaborator Request) */}
          {postType === 'collaborator_request' && (
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Looking for Collaborators with Skills <span className="text-red-500">*</span>
              </label>
              <div className="flex flex-wrap gap-1.5 mb-2">
                {skills.slice(0, 10).map((skill) => {
                  const isSelected = lookingForSkills.includes(skill.name);
                  return (
                    <button
                      key={skill.id}
                      type="button"
                      onClick={() => handleToggleSkill(skill.name)}
                      className={`px-2.5 py-1 rounded-lg text-xs font-medium border transition-colors ${
                        isSelected
                          ? 'bg-blue-600 text-white border-blue-600'
                          : 'bg-white text-slate-700 border-slate-200 hover:border-blue-400 hover:bg-blue-50/50'
                      }`}
                    >
                      {isSelected ? '✓ ' : '+ '}
                      {skill.name}
                    </button>
                  );
                })}
              </div>
              <input
                type="text"
                value={customSkillInput}
                onChange={(e) => setCustomSkillInput(e.target.value)}
                onKeyDown={handleAddCustomSkill}
                placeholder="Or type a custom skill and press Enter (e.g. WebGPU, Rust, Figma)..."
                className="w-full bg-white border border-slate-300 rounded-xl px-3.5 py-2 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
            </div>
          )}

          {/* Text Content */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Description &amp; Goals <span className="text-red-500">*</span>
            </label>
            <textarea
              rows={4}
              value={textContent}
              onChange={(e) => setTextContent(e.target.value)}
              placeholder="Describe your student project, the problem you are solving, your current progress, or the hackathon challenge..."
              className="w-full bg-white border border-slate-300 rounded-2xl p-3.5 text-sm text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>

          {/* Image Attachment */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-semibold text-slate-700 flex items-center gap-1.5">
                <ImageIcon className="w-4 h-4 text-slate-500" />
                Image Attachment (Supabase Storage preview)
              </label>
              <button
                type="button"
                onClick={() => setShowImagePicker(!showImagePicker)}
                className="text-xs text-blue-600 hover:underline font-medium"
              >
                {showImagePicker ? 'Hide sample images' : 'Choose sample media'}
              </button>
            </div>

            {showImagePicker && (
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-3">
                {SAMPLE_PROJECT_IMAGES.map((img) => (
                  <button
                    key={img.name}
                    type="button"
                    onClick={() => {
                      setImagePath(img.url);
                      setShowImagePicker(false);
                    }}
                    className="relative group rounded-xl overflow-hidden border border-slate-200 text-left hover:border-blue-400 transition-colors"
                  >
                    <img src={img.url} alt="" className="w-full h-16 object-cover" />
                    <div className="p-1 bg-slate-900/80 text-[10px] text-white truncate">
                      {img.name}
                    </div>
                  </button>
                ))}
              </div>
            )}

            <div className="flex gap-2">
              <input
                type="text"
                value={imagePath}
                onChange={(e) => setImagePath(e.target.value)}
                placeholder="Or paste an image URL (https://...)"
                className="flex-1 bg-white border border-slate-300 rounded-xl px-3.5 py-2 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
              {imagePath && (
                <button
                  type="button"
                  onClick={() => setImagePath('')}
                  className="px-2.5 py-1 text-xs text-red-600 hover:bg-red-50 rounded-lg font-medium"
                >
                  Clear
                </button>
              )}
            </div>

            {imagePath && (
              <div className="mt-2 rounded-xl overflow-hidden border border-slate-200 max-h-36">
                <img src={imagePath} alt="Preview" className="w-full h-36 object-cover" />
              </div>
            )}
          </div>

          {/* Error Message */}
          {errorMessage && (
            <div className="flex items-center gap-2 p-3 rounded-xl bg-red-50 border border-red-200 text-xs text-red-700">
              <AlertCircle className="w-4 h-4 shrink-0 text-red-600" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Submit CTA */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold shadow-sm transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <Check className="w-4 h-4" />
              Publish Post
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
