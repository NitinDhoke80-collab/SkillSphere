import React, { useState } from 'react';
import { useSkillSphere } from '../services/store';
import { Profile, Post } from '../types';
import { X, Send, CheckCircle2 } from 'lucide-react';
import confetti from 'canvas-confetti';

interface CollabRequestModalProps {
  isOpen: boolean;
  onClose: () => void;
  targetStudent?: Profile | null;
  targetPost?: Post | null;
}

export const CollabRequestModal: React.FC<CollabRequestModalProps> = ({
  isOpen,
  onClose,
  targetStudent,
  targetPost,
}) => {
  const { currentUser, sendCollaborationRequest, profileSkills } = useSkillSphere();

  const recipient = targetStudent || targetPost?.author;
  const [message, setMessage] = useState('');
  const [skillOffered, setSkillOffered] = useState('');
  const [isSent, setIsSent] = useState(false);

  if (!isOpen || !recipient) return null;

  // Current user's proficient skills
  const myProficientSkills = profileSkills
    .filter((ps) => ps.profile_id === currentUser.id && ps.status === 'proficient')
    .map((ps) => ps.skill?.name)
    .filter(Boolean) as string[];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;

    sendCollaborationRequest({
      postId: targetPost?.id || 'direct-invite',
      receiverId: recipient.id,
      message: message.trim(),
      skillOffered: skillOffered || myProficientSkills[0] || 'Full-Stack Development',
    });

    confetti({
      particleCount: 30,
      spread: 60,
      origin: { y: 0.7 },
    });

    setIsSent(true);
    setTimeout(() => {
      setIsSent(false);
      onClose();
      setMessage('');
      setSkillOffered('');
    }, 1500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="bg-white border border-slate-200 rounded-3xl w-full max-w-lg p-6 shadow-2xl">
        {isSent ? (
          <div className="py-8 text-center space-y-3">
            <div className="w-14 h-14 rounded-full bg-emerald-100 text-emerald-600 mx-auto flex items-center justify-center">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <h3 className="font-bold text-lg text-slate-900">
              Collaboration Request Sent!
            </h3>
            <p className="text-xs text-slate-500 max-w-xs mx-auto">
              {recipient.full_name} will receive your message and skills profile.
            </p>
          </div>
        ) : (
          <div>
            {/* Header */}
            <div className="flex items-center justify-between pb-4 border-b border-slate-100 mb-4">
              <div className="flex items-center gap-3">
                <img
                  src={recipient.avatar_url}
                  alt=""
                  className="w-10 h-10 rounded-full object-cover ring-2 ring-blue-500/20"
                />
                <div>
                  <h3 className="font-bold text-slate-900 text-sm">
                    Collaborate with {recipient.full_name}
                  </h3>
                  <p className="text-xs text-blue-600 font-medium">
                    {recipient.university} · {recipient.major}
                  </p>
                </div>
              </div>
              <button
                onClick={onClose}
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {targetPost && (
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs mb-4">
                <span className="font-semibold text-slate-500 uppercase tracking-wider text-[10px] block mb-1">
                  Regarding Project Post:
                </span>
                <p className="font-bold text-slate-900">
                  {targetPost.project_title || targetPost.text_content.slice(0, 60)}...
                </p>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Primary Skill You Bring to the Team
                </label>
                {myProficientSkills.length > 0 ? (
                  <select
                    value={skillOffered}
                    onChange={(e) => setSkillOffered(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  >
                    <option value="">Select a skill from your profile</option>
                    {myProficientSkills.map((sk) => (
                      <option key={sk} value={sk}>
                        {sk}
                      </option>
                    ))}
                  </select>
                ) : (
                  <input
                    type="text"
                    value={skillOffered}
                    onChange={(e) => setSkillOffered(e.target.value)}
                    placeholder="e.g. React, PyTorch, Figma UI..."
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                )}
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Pitch or Message
                </label>
                <textarea
                  rows={4}
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  required
                  placeholder="Introduce yourself, your availability for hackathons or semester projects, and how your skills can help..."
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl p-3 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-3.5 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={!message.trim()}
                  className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white text-xs font-semibold shadow-sm flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Send className="w-3.5 h-3.5" />
                  Send Request
                </button>
              </div>
            </form>
          </div>
        )}
      </div>
    </div>
  );
};
