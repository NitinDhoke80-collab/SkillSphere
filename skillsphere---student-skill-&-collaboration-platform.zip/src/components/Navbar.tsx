import React from 'react';
import { useSkillSphere } from '../services/store';
import {
  Sparkles,
  Users,
  Compass,
  Code2,
  Database,
  Search,
  CheckCircle2,
  ChevronDown,
  UserCheck,
  Plus,
} from 'lucide-react';

interface NavbarProps {
  onOpenCreatePost: () => void;
  onOpenAuthModal: () => void;
  onOpenSupabaseModal: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  onOpenCreatePost,
  onOpenAuthModal,
  onOpenSupabaseModal,
}) => {
  const {
    currentUser,
    allUsers,
    switchUser,
    activeView,
    setActiveView,
    searchQuery,
    setSearchQuery,
    supabaseConfig,
  } = useSkillSphere();

  const [userDropdownOpen, setUserDropdownOpen] = React.useState(false);

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 text-slate-800 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-4">
          {/* Logo & Brand */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => setActiveView('feed')}
              className="flex items-center gap-2.5 text-left group focus:outline-none"
            >
              <div className="w-10 h-10 rounded-xl bg-blue-600 flex items-center justify-center text-white shadow-sm shadow-blue-500/20 group-hover:scale-105 transition-transform">
                <Sparkles className="w-5 h-5 text-white" />
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <span className="font-extrabold text-lg tracking-tight text-slate-900">
                    SkillSphere
                  </span>
                  <span className="text-[10px] uppercase font-semibold tracking-wider px-1.5 py-0.5 rounded bg-blue-50 text-blue-700 border border-blue-200">
                    College MVP
                  </span>
                </div>
                <p className="text-[11px] text-slate-500 hidden sm:block">
                  Student Skills &amp; Project Collaborators
                </p>
              </div>
            </button>
          </div>

          {/* Search bar */}
          <div className="flex-1 max-w-md hidden md:block">
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search students by name, skill (e.g. React, PyTorch), or college..."
                className="w-full bg-slate-100/80 border border-slate-200 rounded-xl pl-10 pr-4 py-2 text-sm text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 focus:bg-white transition-all"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-slate-700"
                >
                  Clear
                </button>
              )}
            </div>
          </div>

          {/* Navigation Links */}
          <nav className="flex items-center gap-1 sm:gap-2">
            <button
              onClick={() => setActiveView('feed')}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-sm font-medium transition-colors ${
                activeView === 'feed'
                  ? 'bg-blue-50 text-blue-700 border border-blue-200'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <Compass className="w-4 h-4" />
              <span className="hidden sm:inline">Feed</span>
            </button>

            <button
              onClick={() => setActiveView('collaborators')}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-sm font-medium transition-colors ${
                activeView === 'collaborators'
                  ? 'bg-blue-50 text-blue-700 border border-blue-200'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <Users className="w-4 h-4" />
              <span className="hidden sm:inline">Find Collaborators</span>
            </button>

            <button
              onClick={() => setActiveView('skills')}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-sm font-medium transition-colors ${
                activeView === 'skills'
                  ? 'bg-blue-50 text-blue-700 border border-blue-200'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <Code2 className="w-4 h-4" />
              <span className="hidden sm:inline">Skills</span>
            </button>

            <button
              onClick={() => setActiveView('sql_schema')}
              className={`flex items-center gap-1.5 px-2.5 py-2 rounded-xl text-sm font-medium transition-colors ${
                activeView === 'sql_schema'
                  ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
              title="View Supabase PostgreSQL Schema & RLS"
            >
              <Database className="w-4 h-4 text-emerald-600" />
              <span className="hidden lg:inline text-xs font-mono font-medium">Supabase SQL</span>
            </button>
          </nav>

          {/* Right Actions */}
          <div className="flex items-center gap-2">
            {/* New Post Button */}
            <button
              onClick={onOpenCreatePost}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold shadow-xs hover:shadow-sm transition-all"
            >
              <Plus className="w-4 h-4" />
              <span className="hidden sm:inline">Share</span>
            </button>

            {/* Supabase status badge */}
            <button
              onClick={onOpenSupabaseModal}
              className={`hidden xl:flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-medium border transition-colors ${
                supabaseConfig.isConnected
                  ? 'bg-emerald-50 border-emerald-200 text-emerald-700'
                  : 'bg-slate-100 border-slate-200 text-slate-700 hover:bg-slate-200/80'
              }`}
            >
              <span
                className={`w-2 h-2 rounded-full ${
                  supabaseConfig.isConnected ? 'bg-emerald-500 animate-pulse' : 'bg-slate-400'
                }`}
              />
              {supabaseConfig.isConnected ? 'Supabase Live' : 'Demo DB (RLS)'}
            </button>

            {/* User Account Switcher Dropdown */}
            <div className="relative">
              <button
                onClick={() => setUserDropdownOpen(!userDropdownOpen)}
                className="flex items-center gap-2 p-1.5 rounded-xl hover:bg-slate-100 border border-slate-200/80 transition-all focus:outline-none"
              >
                <img
                  src={currentUser.avatar_url}
                  alt={currentUser.full_name}
                  className="w-8 h-8 rounded-full object-cover ring-2 ring-blue-500/30"
                />
                <span className="text-sm font-medium text-slate-800 hidden md:block max-w-[100px] truncate">
                  {currentUser.full_name.split(' ')[0]}
                </span>
                <ChevronDown className="w-3.5 h-3.5 text-slate-500" />
              </button>

              {userDropdownOpen && (
                <>
                  <div
                    className="fixed inset-0 z-40"
                    onClick={() => setUserDropdownOpen(false)}
                  />
                  <div className="absolute right-0 mt-2 w-72 rounded-2xl bg-white border border-slate-200 shadow-xl p-2 z-50 text-slate-800 animate-in fade-in zoom-in-95 duration-100">
                    <div className="px-3 py-2 border-b border-slate-100 mb-2">
                      <p className="text-xs text-slate-400 font-medium">Signed in as</p>
                      <p className="font-bold text-slate-900 truncate">{currentUser.full_name}</p>
                      <p className="text-xs font-semibold text-blue-600">{currentUser.university}</p>
                    </div>

                    <button
                      onClick={() => {
                        setActiveView('profile');
                        setUserDropdownOpen(false);
                      }}
                      className="w-full text-left px-3 py-2 text-sm rounded-xl hover:bg-slate-50 hover:text-blue-700 flex items-center gap-2 font-medium"
                    >
                      <UserCheck className="w-4 h-4 text-blue-600" />
                      View My Profile &amp; Skills
                    </button>

                    <div className="mt-2 pt-2 border-t border-slate-100">
                      <p className="px-3 pb-1 text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                        Switch Student Demo
                      </p>
                      {allUsers.map((user) => (
                        <button
                          key={user.id}
                          onClick={() => {
                            switchUser(user.id);
                            setUserDropdownOpen(false);
                          }}
                          className={`w-full text-left px-3 py-1.5 text-xs rounded-xl flex items-center justify-between transition-colors ${
                            user.id === currentUser.id
                              ? 'bg-blue-50 text-blue-800 font-semibold'
                              : 'hover:bg-slate-50 text-slate-700'
                          }`}
                        >
                          <div className="flex items-center gap-2 truncate">
                            <img
                              src={user.avatar_url}
                              alt=""
                              className="w-5 h-5 rounded-full object-cover"
                            />
                            <span className="truncate">{user.full_name}</span>
                          </div>
                          {user.id === currentUser.id && (
                            <CheckCircle2 className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                          )}
                        </button>
                      ))}
                    </div>

                    <div className="mt-2 pt-2 border-t border-slate-100">
                      <button
                        onClick={() => {
                          setUserDropdownOpen(false);
                          onOpenAuthModal();
                        }}
                        className="w-full text-left px-3 py-1.5 text-xs text-slate-500 hover:text-slate-900 hover:bg-slate-50 rounded-xl"
                      >
                        Sign Up / Login Screen...
                      </button>
                    </div>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};
