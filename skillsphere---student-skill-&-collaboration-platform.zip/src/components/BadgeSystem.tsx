import React, { useState } from 'react';
import { useSkillSphere } from '../services/store';
import { StudentBadge, BadgeCategory, BadgeTier } from '../types';
import {
  filterBadgesByCategory,
  getBadgeCounts,
  sortBadgesByTier,
  getTopBadges,
} from '../utils/pureLogic';
import {
  Trophy,
  Medal,
  Award,
  GraduationCap,
  BookOpen,
  Crown,
  Flame,
  ShieldCheck,
  CheckCircle2,
  ExternalLink,
  Plus,
  X,
  Sparkles,
  Share2,
  Check,
  Info,
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface BadgeSystemProps {
  studentId?: string;
  badges?: StudentBadge[];
  variant?: 'compact' | 'full' | 'inline';
  maxDisplay?: number;
  showAwardButton?: boolean;
  className?: string;
}

export const BadgeIcon: React.FC<{ name: string; className?: string }> = ({ name, className = 'w-4 h-4' }) => {
  switch (name) {
    case 'Trophy':
      return <Trophy className={className} />;
    case 'Medal':
      return <Medal className={className} />;
    case 'Award':
      return <Award className={className} />;
    case 'GraduationCap':
      return <GraduationCap className={className} />;
    case 'BookOpen':
      return <BookOpen className={className} />;
    case 'Crown':
      return <Crown className={className} />;
    case 'Flame':
      return <Flame className={className} />;
    case 'ShieldCheck':
    default:
      return <ShieldCheck className={className} />;
  }
};

const getTierStyles = (tier: BadgeTier) => {
  switch (tier) {
    case 'gold':
      return {
        cardBg: 'bg-gradient-to-br from-amber-50/90 via-yellow-50/50 to-white',
        border: 'border-amber-300/80',
        iconBg: 'bg-amber-100 text-amber-700 ring-2 ring-amber-400/40',
        pillBg: 'bg-amber-100 text-amber-900 border-amber-300',
        text: 'text-amber-950',
        subtext: 'text-amber-800',
        label: 'Gold Credential',
      };
    case 'special':
      return {
        cardBg: 'bg-gradient-to-br from-purple-50/90 via-indigo-50/50 to-white',
        border: 'border-purple-300/80',
        iconBg: 'bg-purple-100 text-purple-700 ring-2 ring-purple-400/40',
        pillBg: 'bg-purple-100 text-purple-900 border-purple-300',
        text: 'text-purple-950',
        subtext: 'text-purple-800',
        label: 'Director / Special Honor',
      };
    case 'silver':
      return {
        cardBg: 'bg-gradient-to-br from-slate-50/90 via-blue-50/40 to-white',
        border: 'border-slate-300/90',
        iconBg: 'bg-slate-200 text-slate-700 ring-2 ring-slate-400/30',
        pillBg: 'bg-slate-100 text-slate-800 border-slate-300',
        text: 'text-slate-900',
        subtext: 'text-slate-700',
        label: 'Silver Honors',
      };
    case 'bronze':
    default:
      return {
        cardBg: 'bg-gradient-to-br from-orange-50/80 via-amber-50/40 to-white',
        border: 'border-orange-200/90',
        iconBg: 'bg-orange-100 text-orange-700 ring-2 ring-orange-300/40',
        pillBg: 'bg-orange-100 text-orange-900 border-orange-200',
        text: 'text-orange-950',
        subtext: 'text-orange-800',
        label: 'Milestone Contributor',
      };
  }
};

const getCategoryLabel = (category: BadgeCategory) => {
  switch (category) {
    case 'hackathon':
      return 'Hackathon Win';
    case 'academic':
      return 'Academic Milestone';
    case 'leadership':
      return 'Student Leadership';
  }
};

export const BadgeSystem: React.FC<BadgeSystemProps> = ({
  studentId,
  badges: customBadges,
  variant = 'compact',
  maxDisplay = 3,
  showAwardButton = true,
  className = '',
}) => {
  const { getStudentBadges, awardBadge, allUsers, currentUser } = useSkillSphere();

  const [activeCategory, setActiveCategory] = useState<'all' | BadgeCategory>('all');
  const [selectedBadgeForDetail, setSelectedBadgeForDetail] = useState<StudentBadge | null>(null);
  const [isAwardModalOpen, setIsAwardModalOpen] = useState(false);
  const [copiedBadgeId, setCopiedBadgeId] = useState<string | null>(null);

  // New badge award form state
  const [awardTitle, setAwardTitle] = useState('');
  const [awardCategory, setAwardCategory] = useState<BadgeCategory>('hackathon');
  const [awardIssuer, setAwardIssuer] = useState('');
  const [awardTier, setAwardTier] = useState<BadgeTier>('gold');
  const [awardDate, setAwardDate] = useState('Spring 2026');
  const [awardDescription, setAwardDescription] = useState('');
  const [awardIcon, setAwardIcon] = useState<'Trophy' | 'Medal' | 'Award' | 'GraduationCap' | 'BookOpen' | 'Crown' | 'ShieldCheck'>('Trophy');
  const [awardVerificationUrl, setAwardVerificationUrl] = useState('');

  // Target student info
  const targetStudentId = studentId || currentUser.id;
  const targetStudent = allUsers.find((u) => u.id === targetStudentId);
  const studentBadges = customBadges || getStudentBadges(targetStudentId);

  const sortedBadges = sortBadgesByTier(studentBadges);
  const filteredBadges = filterBadgesByCategory(sortedBadges, activeCategory);
  const counts = getBadgeCounts(studentBadges);

  const handleShareBadge = (badge: StudentBadge) => {
    navigator.clipboard?.writeText(
      `Verified Milestone: ${badge.title} (${badge.issuer}) earned by ${targetStudent?.full_name || 'student'} on SkillSphere!`
    );
    setCopiedBadgeId(badge.id);
    confetti({
      particleCount: 25,
      spread: 60,
      origin: { y: 0.6 },
    });
    setTimeout(() => setCopiedBadgeId(null), 2000);
  };

  const handleAwardSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!awardTitle.trim() || !awardIssuer.trim()) return;

    awardBadge({
      student_id: targetStudentId,
      category: awardCategory,
      title: awardTitle.trim(),
      issuer: awardIssuer.trim(),
      date_earned: awardDate.trim() || '2026',
      description: awardDescription.trim() || `Verified ${awardTitle} milestone earned at ${targetStudent?.university || 'University'}.`,
      icon_name: awardIcon,
      tier: awardTier,
      verified: true,
      verifier_name: `${awardIssuer.trim()} Verification Board`,
      verification_url: awardVerificationUrl.trim() || undefined,
    });

    confetti({
      particleCount: 45,
      spread: 75,
      origin: { y: 0.6 },
    });

    setIsAwardModalOpen(false);
    // Reset form
    setAwardTitle('');
    setAwardIssuer('');
    setAwardDescription('');
    setAwardVerificationUrl('');
  };

  // -------------------------------------------------------------
  // COMPACT VARIANT: Designed for student profile cards
  // -------------------------------------------------------------
  if (variant === 'compact') {
    if (studentBadges.length === 0) {
      return null;
    }

    const displayed = getTopBadges(studentBadges, maxDisplay);
    const remainingCount = studentBadges.length - displayed.length;

    return (
      <div className={`space-y-1.5 ${className}`}>
        <div className="flex items-center gap-1.5 flex-wrap">
          {displayed.map((badge) => {
            const styles = getTierStyles(badge.tier);
            return (
              <button
                key={badge.id}
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  setSelectedBadgeForDetail(badge);
                }}
                title={`${badge.title} - ${badge.issuer} (${badge.date_earned})`}
                className={`group/badge relative inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold border ${styles.border} ${styles.cardBg} ${styles.text} hover:scale-[1.02] active:scale-95 transition-all shadow-2xs cursor-pointer`}
              >
                <span className={`p-0.5 rounded-full ${styles.iconBg}`}>
                  <BadgeIcon name={badge.icon_name} className="w-3 h-3" />
                </span>
                <span className="truncate max-w-[140px] text-[11px] font-bold">
                  {badge.title}
                </span>
                {badge.verified && (
                  <CheckCircle2
                    className="w-3 h-3 text-emerald-600 shrink-0"
                    title={`Verified by ${badge.verifier_name || badge.issuer}`}
                  />
                )}
              </button>
            );
          })}

          {remainingCount > 0 && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                setSelectedBadgeForDetail(studentBadges[0]);
              }}
              className="text-[10px] font-bold px-2 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-600 border border-slate-200 transition-colors"
            >
              +{remainingCount} more
            </button>
          )}
        </div>

        {/* Modal for detail view when clicked from compact card */}
        {selectedBadgeForDetail && (
          <BadgeDetailModal
            badge={selectedBadgeForDetail}
            student={targetStudent}
            onClose={() => setSelectedBadgeForDetail(null)}
            onShare={() => handleShareBadge(selectedBadgeForDetail)}
            isCopied={copiedBadgeId === selectedBadgeForDetail.id}
          />
        )}
      </div>
    );
  }

  // -------------------------------------------------------------
  // INLINE VARIANT: Simple single-row pill badge
  // -------------------------------------------------------------
  if (variant === 'inline') {
    if (studentBadges.length === 0) return null;
    const topBadge = sortedBadges[0];
    const styles = getTierStyles(topBadge.tier);

    return (
      <div className={`inline-flex items-center gap-1.5 ${className}`}>
        <button
          type="button"
          onClick={() => setSelectedBadgeForDetail(topBadge)}
          className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold border ${styles.border} ${styles.cardBg} ${styles.text} hover:shadow-xs transition-all`}
        >
          <BadgeIcon name={topBadge.icon_name} className="w-3 h-3" />
          <span className="truncate max-w-[120px]">{topBadge.title}</span>
          <CheckCircle2 className="w-2.5 h-2.5 text-emerald-600" />
        </button>

        {selectedBadgeForDetail && (
          <BadgeDetailModal
            badge={selectedBadgeForDetail}
            student={targetStudent}
            onClose={() => setSelectedBadgeForDetail(null)}
            onShare={() => handleShareBadge(selectedBadgeForDetail)}
            isCopied={copiedBadgeId === selectedBadgeForDetail.id}
          />
        )}
      </div>
    );
  }

  // -------------------------------------------------------------
  // FULL VARIANT: Expanded showcase on student profile page
  // -------------------------------------------------------------
  return (
    <div className={`bg-white border border-slate-200/90 rounded-3xl p-6 sm:p-7 shadow-xs space-y-6 ${className}`}>
      {/* Header & Stats Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-100">
        <div>
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-2xl bg-amber-50 border border-amber-200 text-amber-600 flex items-center justify-center shadow-2xs">
              <Trophy className="w-5 h-5 text-amber-600" />
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
                Earned Campus Badges &amp; Milestones
                <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-blue-50 text-blue-700 border border-blue-200">
                  {counts.total} Credentials
                </span>
              </h2>
              <p className="text-xs text-slate-500">
                Peer-verified hackathon championships, honors lists, and academic fellowships
              </p>
            </div>
          </div>
        </div>

        {showAwardButton && (
          <button
            type="button"
            onClick={() => setIsAwardModalOpen(true)}
            className="self-start sm:self-auto flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-blue-50 hover:bg-blue-100 text-blue-700 text-xs font-semibold border border-blue-200 transition-colors shadow-2xs cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            Verify / Award Milestone
          </button>
        )}
      </div>

      {/* Category Filter Pills & Summary Cards */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0">
          <button
            type="button"
            onClick={() => setActiveCategory('all')}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
              activeCategory === 'all'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            All Badges ({counts.total})
          </button>
          <button
            type="button"
            onClick={() => setActiveCategory('hackathon')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
              activeCategory === 'hackathon'
                ? 'bg-amber-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            <Trophy className="w-3.5 h-3.5 text-amber-500" />
            Hackathon Wins ({counts.hackathon})
          </button>
          <button
            type="button"
            onClick={() => setActiveCategory('academic')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
              activeCategory === 'academic'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            <GraduationCap className="w-3.5 h-3.5 text-indigo-500" />
            Academic Milestones ({counts.academic})
          </button>
          {counts.leadership > 0 && (
            <button
              type="button"
              onClick={() => setActiveCategory('leadership')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                activeCategory === 'leadership'
                  ? 'bg-purple-600 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <Crown className="w-3.5 h-3.5 text-purple-500" />
              Leadership ({counts.leadership})
            </button>
          )}
        </div>

        <div className="flex items-center gap-1.5 text-xs text-slate-500 font-medium">
          <ShieldCheck className="w-4 h-4 text-emerald-600" />
          <span>{counts.verified} Verified Credentials</span>
        </div>
      </div>

      {/* Badges Grid */}
      {filteredBadges.length === 0 ? (
        <div className="p-8 text-center bg-slate-50 border border-slate-200/80 rounded-2xl">
          <Award className="w-8 h-8 text-slate-300 mx-auto mb-2" />
          <p className="text-xs text-slate-600 font-medium">No badges in this category yet.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredBadges.map((badge) => {
            const styles = getTierStyles(badge.tier);
            return (
              <div
                key={badge.id}
                onClick={() => setSelectedBadgeForDetail(badge)}
                className={`relative group rounded-2xl border ${styles.border} ${styles.cardBg} p-5 flex flex-col justify-between hover:shadow-md transition-all cursor-pointer`}
              >
                <div>
                  {/* Top Bar: Icon Medallion & Category Tag */}
                  <div className="flex items-start justify-between gap-2 mb-3">
                    <div className="flex items-center gap-3">
                      <div className={`w-11 h-11 rounded-2xl ${styles.iconBg} flex items-center justify-center shadow-xs group-hover:scale-105 transition-transform`}>
                        <BadgeIcon name={badge.icon_name} className="w-6 h-6" />
                      </div>
                      <div>
                        <span className={`inline-block text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full border ${styles.pillBg}`}>
                          {getCategoryLabel(badge.category)}
                        </span>
                        <p className="text-[11px] text-slate-500 mt-0.5">{badge.date_earned}</p>
                      </div>
                    </div>

                    {badge.verified && (
                      <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                        <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                        Verified
                      </span>
                    )}
                  </div>

                  {/* Title & Description */}
                  <h3 className={`font-bold text-sm leading-snug ${styles.text} mb-1.5 group-hover:text-blue-600 transition-colors`}>
                    {badge.title}
                  </h3>
                  <p className="text-xs text-slate-600 line-clamp-3 leading-relaxed mb-3">
                    {badge.description}
                  </p>
                </div>

                {/* Footer: Issuer & Quick Actions */}
                <div className="pt-3 border-t border-slate-200/60 flex items-center justify-between text-xs text-slate-500">
                  <span className="truncate text-[11px] font-medium text-slate-600" title={badge.issuer}>
                    {badge.issuer}
                  </span>

                  <span className="text-[11px] text-blue-600 font-semibold group-hover:underline flex items-center gap-1">
                    Inspect
                    <ExternalLink className="w-3 h-3" />
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Badge Certificate Detail Modal */}
      {selectedBadgeForDetail && (
        <BadgeDetailModal
          badge={selectedBadgeForDetail}
          student={targetStudent}
          onClose={() => setSelectedBadgeForDetail(null)}
          onShare={() => handleShareBadge(selectedBadgeForDetail)}
          isCopied={copiedBadgeId === selectedBadgeForDetail.id}
        />
      )}

      {/* Award / Verify Credential Modal */}
      {isAwardModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm animate-in fade-in duration-150">
          <div className="bg-white border border-slate-200 rounded-3xl w-full max-w-lg p-6 shadow-2xl">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100 mb-4">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center border border-blue-200">
                  <Award className="w-5 h-5 text-blue-600" />
                </div>
                <div>
                  <h3 className="font-bold text-slate-900 text-sm">
                    Award Campus Credential / Milestone
                  </h3>
                  <p className="text-xs text-slate-500">
                    Issuing to {targetStudent?.full_name || 'Student'} ({targetStudent?.university})
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsAwardModalOpen(false)}
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAwardSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Category <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={awardCategory}
                    onChange={(e) => setAwardCategory(e.target.value as BadgeCategory)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="hackathon">🏆 Hackathon Win</option>
                    <option value="academic">🎓 Academic Milestone</option>
                    <option value="leadership">🌟 Student Leadership</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Badge Tier <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={awardTier}
                    onChange={(e) => setAwardTier(e.target.value as BadgeTier)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="gold">Gold (1st Place / Top Honors)</option>
                    <option value="special">Special / Flagship Director</option>
                    <option value="silver">Silver (Finalist / Dean List)</option>
                    <option value="bronze">Bronze (Contributor / Fellow)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Credential Title <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={awardTitle}
                  onChange={(e) => setAwardTitle(e.target.value)}
                  placeholder="e.g. TreeHacks Grand Prize Winner or Dean's Honors List"
                  required
                  className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Issuing Organization <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={awardIssuer}
                    onChange={(e) => setAwardIssuer(e.target.value)}
                    placeholder="e.g. MIT TechX or UC Berkeley EECS"
                    required
                    className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Date / Term Earned
                  </label>
                  <input
                    type="text"
                    value={awardDate}
                    onChange={(e) => setAwardDate(e.target.value)}
                    placeholder="e.g. Spring 2026 or Fall 2025"
                    className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Description &amp; Achievements
                </label>
                <textarea
                  rows={3}
                  value={awardDescription}
                  onChange={(e) => setAwardDescription(e.target.value)}
                  placeholder="Summarize the accomplishment, project scope, competition metrics, or academic excellence criteria..."
                  className="w-full bg-white border border-slate-300 rounded-xl p-2.5 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Verification Proof Link (Devpost, Paper, or Dept URL)
                </label>
                <input
                  type="text"
                  value={awardVerificationUrl}
                  onChange={(e) => setAwardVerificationUrl(e.target.value)}
                  placeholder="https://devpost.com/software/... or https://..."
                  className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsAwardModalOpen(false)}
                  className="px-3.5 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={!awardTitle.trim() || !awardIssuer.trim()}
                  className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white text-xs font-semibold shadow-xs flex items-center gap-1.5 cursor-pointer"
                >
                  <Award className="w-4 h-4" />
                  Grant &amp; Verify Credential
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

// -------------------------------------------------------------
// BADGE DETAIL / CERTIFICATE MODAL
// -------------------------------------------------------------
interface BadgeDetailModalProps {
  badge: StudentBadge;
  student?: any;
  onClose: () => void;
  onShare: () => void;
  isCopied: boolean;
}

const BadgeDetailModal: React.FC<BadgeDetailModalProps> = ({
  badge,
  student,
  onClose,
  onShare,
  isCopied,
}) => {
  const styles = getTierStyles(badge.tier);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="bg-white border border-slate-200 rounded-3xl w-full max-w-lg overflow-hidden shadow-2xl animate-in zoom-in-95 duration-150">
        {/* Certificate Style Header */}
        <div className={`p-6 ${styles.cardBg} border-b ${styles.border} relative`}>
          <button
            type="button"
            onClick={onClose}
            className="absolute top-4 right-4 p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-white/80 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-3.5">
            <div className={`w-14 h-14 rounded-2xl ${styles.iconBg} flex items-center justify-center shadow-md`}>
              <BadgeIcon name={badge.icon_name} className="w-8 h-8" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className={`text-[10px] font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full border ${styles.pillBg}`}>
                  {getCategoryLabel(badge.category)}
                </span>
                <span className="text-[10px] font-semibold text-slate-500">
                  {styles.label}
                </span>
              </div>
              <h3 className={`text-lg font-extrabold ${styles.text} mt-1 leading-snug`}>
                {badge.title}
              </h3>
            </div>
          </div>
        </div>

        {/* Certificate Body */}
        <div className="p-6 space-y-4">
          {/* Issued to Student */}
          {student && (
            <div className="flex items-center justify-between p-3 rounded-2xl bg-slate-50 border border-slate-200">
              <div className="flex items-center gap-2.5">
                <img
                  src={student.avatar_url}
                  alt={student.full_name}
                  className="w-10 h-10 rounded-xl object-cover ring-2 ring-blue-500/20"
                />
                <div>
                  <p className="text-xs font-bold text-slate-900">{student.full_name}</p>
                  <p className="text-[11px] text-blue-600 font-medium">
                    {student.university} · {student.major}
                  </p>
                </div>
              </div>
              <span className="text-[11px] text-slate-500 font-medium">{badge.date_earned}</span>
            </div>
          )}

          {/* Achievement Description */}
          <div>
            <h4 className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1">
              Achievement Details
            </h4>
            <p className="text-xs text-slate-700 leading-relaxed bg-slate-50/60 p-3 rounded-xl border border-slate-100">
              {badge.description}
            </p>
          </div>

          {/* Verification Details */}
          <div className="p-3.5 rounded-2xl bg-emerald-50/60 border border-emerald-200 flex items-start gap-3">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
            <div className="text-xs">
              <p className="font-bold text-emerald-900">Cryptographically &amp; Peer Verified</p>
              <p className="text-emerald-800 text-[11px] mt-0.5">
                Issued by <strong>{badge.issuer}</strong>
                {badge.verifier_name && ` · Attested by ${badge.verifier_name}`}.
              </p>
            </div>
          </div>

          {/* Verification Link if provided */}
          {badge.verification_url && (
            <div>
              <a
                href={badge.verification_url}
                target="_blank"
                rel="noreferrer"
                className="w-full py-2 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold border border-slate-200 transition-colors flex items-center justify-center gap-1.5"
              >
                <span>View Official Submission / Proof</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>
          )}

          {/* Actions */}
          <div className="pt-2 flex items-center justify-end gap-2 border-t border-slate-100">
            <button
              type="button"
              onClick={onShare}
              className="px-4 py-2 rounded-xl border border-slate-200 text-slate-700 hover:bg-slate-50 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              {isCopied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Copied Verification Text!</span>
                </>
              ) : (
                <>
                  <Share2 className="w-3.5 h-3.5" />
                  <span>Share Credential</span>
                </>
              )}
            </button>
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold shadow-xs cursor-pointer"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
