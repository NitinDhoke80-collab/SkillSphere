import React, { useState } from 'react';
import { Post, Comment } from '../types';
import { useSkillSphere } from '../services/store';
import { formatRelativeTime } from '../utils/pureLogic';
import { BadgeSystem } from './BadgeSystem';
import {
  Heart,
  MessageSquare,
  Users,
  Trophy,
  GitBranch,
  ExternalLink,
  Trash2,
  Send,
  Sparkles,
  Share2,
  Check,
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface PostCardProps {
  post: Post;
  onOpenCollabModal?: (post: Post) => void;
}

export const PostCard: React.FC<PostCardProps> = ({ post, onOpenCollabModal }) => {
  const {
    currentUser,
    toggleLike,
    deletePost,
    addComment,
    comments,
    setSelectedSkillFilter,
    setActiveView,
    setViewingProfileId,
  } = useSkillSphere();

  const [showComments, setShowComments] = useState(false);
  const [commentText, setCommentText] = useState('');
  const [copiedLink, setCopiedLink] = useState(false);

  const postComments: Comment[] = comments.filter((c) => c.post_id === post.id);
  const isAuthor = currentUser.id === post.author_id;

  const handleLike = () => {
    if (!post.user_has_liked) {
      // Trigger tiny celebratory burst on achievement likes
      if (post.post_type === 'achievement') {
        confetti({
          particleCount: 25,
          spread: 60,
          origin: { y: 0.8 },
        });
      }
    }
    toggleLike(post.id);
  };

  const handleAddComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentText.trim()) return;
    addComment(post.id, commentText);
    setCommentText('');
  };

  const handleShare = () => {
    navigator.clipboard?.writeText(window.location.href);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  // Badge styles based on post type
  const renderBadge = () => {
    switch (post.post_type) {
      case 'collaborator_request':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-blue-50 text-blue-700 border border-blue-200">
            <Users className="w-3.5 h-3.5 text-blue-600" />
            Collaborator Needed
          </span>
        );
      case 'achievement':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-amber-50 text-amber-800 border border-amber-200">
            <Trophy className="w-3.5 h-3.5 text-amber-600" />
            Achievement Unlocked
          </span>
        );
      case 'project_update':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200">
            <GitBranch className="w-3.5 h-3.5 text-emerald-600" />
            Project Milestone
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-slate-100 text-slate-700 border border-slate-200">
            <Sparkles className="w-3.5 h-3.5 text-slate-500" />
            Campus Update
          </span>
        );
    }
  };

  return (
    <article className="bg-white border border-slate-200/90 rounded-2xl shadow-xs hover:shadow-sm transition-shadow overflow-hidden">
      {/* Header */}
      <div className="p-5 pb-3">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                setViewingProfileId(post.author_id);
                setActiveView('profile');
              }}
              className="group focus:outline-none"
            >
              <img
                src={post.author?.avatar_url || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150'}
                alt={post.author?.full_name || 'Student'}
                className="w-11 h-11 rounded-full object-cover ring-2 ring-blue-500/20 group-hover:ring-blue-500 transition-all"
              />
            </button>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <button
                  onClick={() => {
                    setViewingProfileId(post.author_id);
                    setActiveView('profile');
                  }}
                  className="font-bold text-slate-900 hover:text-blue-600 text-sm transition-colors text-left"
                >
                  {post.author?.full_name || 'Student Author'}
                </button>
                <span className="text-xs text-slate-400">@{post.author?.username}</span>
                <span className="text-slate-300">•</span>
                <span className="text-xs font-semibold text-blue-600">
                  {post.author?.university}
                </span>
                <BadgeSystem studentId={post.author_id} variant="inline" />
              </div>
              <div className="flex items-center gap-2 text-xs text-slate-500 mt-0.5">
                <span>{post.author?.major}</span>
                <span>•</span>
                <span>{formatRelativeTime(post.created_at)}</span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {renderBadge()}
            {isAuthor && (
              <button
                onClick={() => {
                  if (confirm('Delete this post? (RLS check: auth.uid() == author_id)')) {
                    deletePost(post.id);
                  }
                }}
                className="p-1.5 text-slate-400 hover:text-red-600 rounded-lg hover:bg-red-50 transition-colors"
                title="Delete your post"
                aria-label="Delete your post"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>

        {/* Project Title & Repo link if available */}
        {post.project_title && (
          <div className="mt-4 p-3.5 rounded-xl bg-slate-50 border border-slate-200/80 flex items-center justify-between gap-3">
            <div className="flex items-center gap-2.5 truncate">
              <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center shrink-0">
                <GitBranch className="w-4 h-4" />
              </div>
              <div className="truncate">
                <p className="text-xs font-medium text-slate-400 uppercase tracking-wider">Project</p>
                <p className="font-semibold text-slate-900 text-sm truncate">
                  {post.project_title}
                </p>
              </div>
            </div>
            {post.project_repo && (
              <a
                href={post.project_repo}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-medium bg-white text-slate-700 border border-slate-200 hover:bg-slate-50 hover:text-blue-600 shrink-0 transition-colors"
              >
                <GitBranch className="w-3.5 h-3.5" />
                Repo
                <ExternalLink className="w-3 h-3 ml-0.5 opacity-60" />
              </a>
            )}
          </div>
        )}

        {/* Text Content */}
        <p className="mt-3.5 text-slate-800 text-sm leading-relaxed whitespace-pre-line">
          {post.text_content}
        </p>

        {/* Skills needed / looking for */}
        {post.looking_for_skills && post.looking_for_skills.length > 0 && (
          <div className="mt-3 pt-3 border-t border-slate-100">
            <span className="text-xs font-semibold text-slate-500 block mb-1.5">
              Seeking Collaborator Skills:
            </span>
            <div className="flex flex-wrap gap-1.5">
              {post.looking_for_skills.map((skillName) => (
                <button
                  key={skillName}
                  onClick={() => {
                    setSelectedSkillFilter(skillName);
                    setActiveView('collaborators');
                  }}
                  className="px-2.5 py-1 rounded-lg text-xs font-medium bg-blue-50/80 hover:bg-blue-100 text-blue-700 border border-blue-200/60 transition-colors"
                >
                  +{skillName}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Post Image attachment */}
      {post.image_path && (
        <div className="relative border-y border-slate-200/80 bg-slate-50 max-h-96 overflow-hidden">
          <img
            src={post.image_path}
            alt="Project media"
            className="w-full h-auto object-cover max-h-96"
            loading="lazy"
          />
        </div>
      )}

      {/* Action Bar */}
      <div className="px-5 py-3 bg-slate-50/70 border-t border-slate-100 flex items-center justify-between">
        <div className="flex items-center gap-1 sm:gap-4">
          {/* Like */}
          <button
            onClick={handleLike}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
              post.user_has_liked
                ? 'bg-rose-50 text-rose-600 ring-1 ring-rose-200'
                : 'text-slate-600 hover:bg-slate-200/60'
            }`}
            aria-label="Like post"
          >
            <Heart
              className={`w-4 h-4 transition-transform ${
                post.user_has_liked ? 'fill-current scale-110' : ''
              }`}
            />
            <span>{post.likes_count}</span>
          </button>

          {/* Comment */}
          <button
            onClick={() => setShowComments(!showComments)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-200/60 transition-colors"
            aria-label="Comments"
          >
            <MessageSquare className="w-4 h-4" />
            <span>{postComments.length}</span>
          </button>

          {/* Share */}
          <button
            onClick={handleShare}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-200/60 transition-colors"
            title="Copy link"
            aria-label="Share post link"
          >
            {copiedLink ? <Check className="w-4 h-4 text-emerald-600" /> : <Share2 className="w-4 h-4" />}
            <span className="hidden sm:inline">{copiedLink ? 'Copied' : 'Share'}</span>
          </button>
        </div>

        {/* Join as Collaborator CTA */}
        {post.post_type === 'collaborator_request' && !isAuthor && (
          <button
            onClick={() => onOpenCollabModal?.(post)}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-semibold bg-blue-600 hover:bg-blue-700 text-white shadow-xs transition-all"
          >
            <Users className="w-3.5 h-3.5" />
            Join Project
          </button>
        )}
      </div>

      {/* Comments Thread (Expandable) */}
      {showComments && (
        <div className="p-5 pt-3 bg-slate-50 border-t border-slate-200">
          {/* Add comment form */}
          <form onSubmit={handleAddComment} className="flex gap-2 mb-4">
            <img
              src={currentUser.avatar_url}
              alt=""
              className="w-8 h-8 rounded-full object-cover shrink-0 mt-0.5"
            />
            <div className="flex-1 flex gap-2">
              <input
                type="text"
                value={commentText}
                onChange={(e) => setCommentText(e.target.value)}
                placeholder="Write a constructive student comment..."
                className="flex-1 bg-white border border-slate-200 rounded-xl px-3.5 py-2 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
              />
              <button
                type="submit"
                disabled={!commentText.trim()}
                className="px-3.5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white text-xs font-semibold transition-all flex items-center gap-1"
                aria-label="Submit comment"
              >
                <Send className="w-3.5 h-3.5" />
              </button>
            </div>
          </form>

          {/* Comments List */}
          <div className="space-y-2.5">
            {postComments.length === 0 ? (
              <p className="text-xs text-slate-400 italic py-2">
                No comments yet. Be the first student to collaborate!
              </p>
            ) : (
              postComments.map((comm) => (
                <div key={comm.id} className="flex items-start gap-2.5 text-xs">
                  <img
                    src={comm.author?.avatar_url || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150'}
                    alt=""
                    className="w-7 h-7 rounded-full object-cover shrink-0 mt-0.5"
                  />
                  <div className="flex-1 bg-white p-3 rounded-xl border border-slate-200/80 shadow-2xs">
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-semibold text-slate-900">
                        {comm.author?.full_name || 'Student'}
                      </span>
                      <span className="text-[10px] text-slate-400">
                        {formatRelativeTime(comm.created_at)}
                      </span>
                    </div>
                    <p className="text-slate-700 leading-normal">
                      {comm.text_content}
                    </p>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </article>
  );
};
