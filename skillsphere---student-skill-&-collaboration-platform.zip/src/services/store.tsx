import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  Profile,
  Skill,
  ProfileSkill,
  Post,
  Comment,
  CollaborationRequest,
  SupabaseConfig,
  SkillStatus,
  PostType,
  StudentBadge,
} from '../types';
import {
  INITIAL_PROFILES,
  INITIAL_SKILLS,
  INITIAL_PROFILE_SKILLS,
  INITIAL_POSTS,
  INITIAL_COMMENTS,
  INITIAL_BADGES,
} from '../data/seedData';
import { createClient, SupabaseClient } from '@supabase/supabase-js';

interface SkillSphereContextType {
  currentUser: Profile;
  allUsers: Profile[];
  skills: Skill[];
  profileSkills: ProfileSkill[];
  posts: Post[];
  comments: Comment[];
  collaborationRequests: CollaborationRequest[];
  badges: StudentBadge[];
  supabaseConfig: SupabaseConfig;
  activeView: 'feed' | 'collaborators' | 'skills' | 'profile' | 'sql_schema';
  setActiveView: (view: 'feed' | 'collaborators' | 'skills' | 'profile' | 'sql_schema') => void;
  viewingProfileId: string | null;
  setViewingProfileId: (id: string | null) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  selectedSkillFilter: string;
  setSelectedSkillFilter: (skill: string) => void;

  // Actions
  switchUser: (userId: string) => void;
  updateProfile: (updatedData: Partial<Profile>) => void;
  addOrUpdateSkill: (skillId: string, status: SkillStatus) => void;
  removeSkill: (skillId: string) => void;
  endorseSkill: (profileSkillId: string) => boolean;
  getStudentBadges: (studentId: string) => StudentBadge[];
  awardBadge: (newBadge: Omit<StudentBadge, 'id' | 'created_at'>) => void;
  createPost: (postData: {
    post_type: PostType;
    text_content: string;
    project_title?: string;
    project_repo?: string;
    looking_for_skills?: string[];
    image_path?: string;
  }) => void;
  deletePost: (postId: string) => void;
  toggleLike: (postId: string) => void;
  addComment: (postId: string, text: string) => void;
  sendCollaborationRequest: (data: {
    postId: string;
    receiverId: string;
    message: string;
    skillOffered: string;
  }) => void;
  saveSupabaseConfig: (url: string, key: string) => Promise<{ success: boolean; error?: string }>;
  resetToSampleData: () => void;
}

const STORAGE_KEY_PREFIX = 'skillsphere_v1_';

const SkillSphereContext = createContext<SkillSphereContextType | null>(null);

export const SkillSphereProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Profiles
  const [allUsers, setAllUsers] = useState<Profile[]>(() => {
    try {
      const stored = localStorage.getItem(`${STORAGE_KEY_PREFIX}profiles`);
      return stored ? JSON.parse(stored) : INITIAL_PROFILES;
    } catch {
      return INITIAL_PROFILES;
    }
  });

  // Current logged in user (defaults to Alex Rivera)
  const [currentUserId, setCurrentUserId] = useState<string>(() => {
    try {
      const stored = localStorage.getItem(`${STORAGE_KEY_PREFIX}current_user_id`);
      return stored || INITIAL_PROFILES[0].id;
    } catch {
      return INITIAL_PROFILES[0].id;
    }
  });

  // Skills catalogue
  const [skills, setSkills] = useState<Skill[]>(() => {
    try {
      const stored = localStorage.getItem(`${STORAGE_KEY_PREFIX}skills`);
      return stored ? JSON.parse(stored) : INITIAL_SKILLS;
    } catch {
      return INITIAL_SKILLS;
    }
  });

  // Profile-Skills mapping
  const [profileSkills, setProfileSkills] = useState<ProfileSkill[]>(() => {
    try {
      const stored = localStorage.getItem(`${STORAGE_KEY_PREFIX}profile_skills`);
      return stored ? JSON.parse(stored) : INITIAL_PROFILE_SKILLS;
    } catch {
      return INITIAL_PROFILE_SKILLS;
    }
  });

  // Posts
  const [posts, setPosts] = useState<Post[]>(() => {
    try {
      const stored = localStorage.getItem(`${STORAGE_KEY_PREFIX}posts`);
      return stored ? JSON.parse(stored) : INITIAL_POSTS;
    } catch {
      return INITIAL_POSTS;
    }
  });

  // Comments
  const [comments, setComments] = useState<Comment[]>(() => {
    try {
      const stored = localStorage.getItem(`${STORAGE_KEY_PREFIX}comments`);
      return stored ? JSON.parse(stored) : INITIAL_COMMENTS;
    } catch {
      return INITIAL_COMMENTS;
    }
  });

  // Collab requests
  const [collaborationRequests, setCollaborationRequests] = useState<CollaborationRequest[]>(() => {
    try {
      const stored = localStorage.getItem(`${STORAGE_KEY_PREFIX}collab_requests`);
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  });

  // Badges
  const [badges, setBadges] = useState<StudentBadge[]>(() => {
    try {
      const stored = localStorage.getItem(`${STORAGE_KEY_PREFIX}badges`);
      return stored ? JSON.parse(stored) : INITIAL_BADGES;
    } catch {
      return INITIAL_BADGES;
    }
  });

  // Supabase connection configuration
  const [supabaseConfig, setSupabaseConfig] = useState<SupabaseConfig>(() => {
    try {
      const stored = localStorage.getItem(`${STORAGE_KEY_PREFIX}supabase_config`);
      return stored
        ? JSON.parse(stored)
        : {
            supabaseUrl: '',
            supabaseAnonKey: '',
            isConnected: false,
          };
    } catch {
      return { supabaseUrl: '', supabaseAnonKey: '', isConnected: false };
    }
  });

  // Navigation and filtering
  const [activeView, setActiveView] = useState<'feed' | 'collaborators' | 'skills' | 'profile' | 'sql_schema'>('feed');
  const [viewingProfileId, setViewingProfileId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedSkillFilter, setSelectedSkillFilter] = useState<string>('');

  // Persist state to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(`${STORAGE_KEY_PREFIX}profiles`, JSON.stringify(allUsers));
      localStorage.setItem(`${STORAGE_KEY_PREFIX}current_user_id`, currentUserId);
      localStorage.setItem(`${STORAGE_KEY_PREFIX}skills`, JSON.stringify(skills));
      localStorage.setItem(`${STORAGE_KEY_PREFIX}profile_skills`, JSON.stringify(profileSkills));
      localStorage.setItem(`${STORAGE_KEY_PREFIX}posts`, JSON.stringify(posts));
      localStorage.setItem(`${STORAGE_KEY_PREFIX}comments`, JSON.stringify(comments));
      localStorage.setItem(`${STORAGE_KEY_PREFIX}collab_requests`, JSON.stringify(collaborationRequests));
      localStorage.setItem(`${STORAGE_KEY_PREFIX}badges`, JSON.stringify(badges));
      localStorage.setItem(`${STORAGE_KEY_PREFIX}supabase_config`, JSON.stringify(supabaseConfig));
    } catch (e) {
      console.warn('LocalStorage save error:', e);
    }
  }, [allUsers, currentUserId, skills, profileSkills, posts, comments, collaborationRequests, badges, supabaseConfig]);

  // Enrich student profiles with their badges
  const enrichedUsers = allUsers.map((user) => ({
    ...user,
    badges: badges.filter((b) => b.student_id === user.id),
  }));

  const currentUser = enrichedUsers.find((u) => u.id === currentUserId) || enrichedUsers[0];

  // Helper to switch active student user
  const switchUser = (userId: string) => {
    const found = allUsers.find((u) => u.id === userId);
    if (found) {
      setCurrentUserId(found.id);
    }
  };

  // Update student profile
  const updateProfile = (updatedData: Partial<Profile>) => {
    setAllUsers((prev) =>
      prev.map((user) => {
        if (user.id === currentUserId) {
          return {
            ...user,
            ...updatedData,
            updated_at: new Date().toISOString(),
          };
        }
        return user;
      })
    );
  };

  // Add or update skill status for current user
  const addOrUpdateSkill = (skillId: string, status: SkillStatus) => {
    setProfileSkills((prev) => {
      const existing = prev.find(
        (ps) => ps.profile_id === currentUserId && ps.skill_id === skillId
      );
      if (existing) {
        return prev.map((ps) =>
          ps.id === existing.id ? { ...ps, status } : ps
        );
      } else {
        const targetSkill = skills.find((s) => s.id === skillId);
        const newPs: ProfileSkill = {
          id: `ps-${Date.now()}`,
          profile_id: currentUserId,
          skill_id: skillId,
          skill: targetSkill,
          status,
          endorsements_count: 0,
          endorsed_by: [],
          created_at: new Date().toISOString(),
        };
        return [...prev, newPs];
      }
    });
  };

  // Remove skill from profile
  const removeSkill = (skillId: string) => {
    setProfileSkills((prev) =>
      prev.filter(
        (ps) => !(ps.profile_id === currentUserId && ps.skill_id === skillId)
      )
    );
  };

  // Endorse another student's skill
  const endorseSkill = (profileSkillId: string): boolean => {
    let endorsed = false;
    setProfileSkills((prev) =>
      prev.map((ps) => {
        if (ps.id === profileSkillId) {
          // Cannot endorse own skill
          if (ps.profile_id === currentUserId) return ps;

          const endorsedBy = ps.endorsed_by || [];
          if (endorsedBy.includes(currentUserId)) {
            // Un-endorse
            return {
              ...ps,
              endorsements_count: Math.max(0, ps.endorsements_count - 1),
              endorsed_by: endorsedBy.filter((id) => id !== currentUserId),
            };
          } else {
            // Endorse
            endorsed = true;
            return {
              ...ps,
              endorsements_count: ps.endorsements_count + 1,
              endorsed_by: [...endorsedBy, currentUserId],
            };
          }
        }
        return ps;
      })
    );
    return endorsed;
  };

  // Create post
  const createPost = (postData: {
    post_type: PostType;
    text_content: string;
    project_title?: string;
    project_repo?: string;
    looking_for_skills?: string[];
    image_path?: string;
  }) => {
    const newPost: Post = {
      id: `post-${Date.now()}`,
      author_id: currentUserId,
      author: currentUser,
      post_type: postData.post_type,
      text_content: postData.text_content,
      project_title: postData.project_title,
      project_repo: postData.project_repo,
      looking_for_skills: postData.looking_for_skills || [],
      image_path: postData.image_path,
      likes_count: 0,
      comments_count: 0,
      user_has_liked: false,
      created_at: new Date().toISOString(),
    };

    setPosts((prev) => [newPost, ...prev]);
  };

  // Delete own post (enforcing RLS rule in UI)
  const deletePost = (postId: string) => {
    setPosts((prev) => prev.filter((p) => !(p.id === postId && p.author_id === currentUserId)));
    setComments((prev) => prev.filter((c) => c.post_id !== postId));
  };

  // Toggle like on a post
  const toggleLike = (postId: string) => {
    setPosts((prev) =>
      prev.map((post) => {
        if (post.id === postId) {
          const hasLiked = !!post.user_has_liked;
          return {
            ...post,
            user_has_liked: !hasLiked,
            likes_count: hasLiked ? Math.max(0, post.likes_count - 1) : post.likes_count + 1,
          };
        }
        return post;
      })
    );
  };

  // Add comment
  const addComment = (postId: string, text: string) => {
    if (!text.trim()) return;

    const newComment: Comment = {
      id: `comm-${Date.now()}`,
      post_id: postId,
      author_id: currentUserId,
      author: currentUser,
      text_content: text.trim(),
      created_at: new Date().toISOString(),
    };

    setComments((prev) => [...prev, newComment]);
    setPosts((prev) =>
      prev.map((post) =>
        post.id === postId
          ? { ...post, comments_count: post.comments_count + 1 }
          : post
      )
    );
  };

  // Send collaboration request
  const sendCollaborationRequest = (data: {
    postId: string;
    receiverId: string;
    message: string;
    skillOffered: string;
  }) => {
    const newReq: CollaborationRequest = {
      id: `collab-${Date.now()}`,
      post_id: data.postId,
      sender_id: currentUserId,
      sender: currentUser,
      receiver_id: data.receiverId,
      message: data.message,
      skill_offered: data.skillOffered,
      status: 'pending',
      created_at: new Date().toISOString(),
    };

    setCollaborationRequests((prev) => [newReq, ...prev]);
  };

  // Test and save live Supabase credentials
  const saveSupabaseConfig = async (url: string, key: string) => {
    if (!url || !key) {
      setSupabaseConfig({ supabaseUrl: '', supabaseAnonKey: '', isConnected: false });
      return { success: true };
    }

    try {
      const client: SupabaseClient = createClient(url, key);
      // Test query to check credentials
      const { error } = await client.from('skills').select('count', { count: 'exact', head: true });
      if (error && error.code !== 'PGRST116') {
        return { success: false, error: error.message };
      }
      setSupabaseConfig({ supabaseUrl: url, supabaseAnonKey: key, isConnected: true });
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message || 'Connection failed' };
    }
  };

  // Get badges for a specific student
  const getStudentBadges = (studentId: string): StudentBadge[] => {
    return badges.filter((b) => b.student_id === studentId);
  };

  // Award a new credential/badge to a student
  const awardBadge = (newBadge: Omit<StudentBadge, 'id' | 'created_at'>) => {
    const badge: StudentBadge = {
      ...newBadge,
      id: `badge-${Date.now()}`,
      created_at: new Date().toISOString(),
    };
    setBadges((prev) => [badge, ...prev]);
  };

  // Reset demo state
  const resetToSampleData = () => {
    setAllUsers(INITIAL_PROFILES);
    setCurrentUserId(INITIAL_PROFILES[0].id);
    setSkills(INITIAL_SKILLS);
    setProfileSkills(INITIAL_PROFILE_SKILLS);
    setPosts(INITIAL_POSTS);
    setComments(INITIAL_COMMENTS);
    setCollaborationRequests([]);
    setBadges(INITIAL_BADGES);
  };

  // Hydrate author and skills references into posts & profileSkills
  const enrichedProfileSkills = profileSkills.map((ps) => ({
    ...ps,
    skill: ps.skill || skills.find((s) => s.id === ps.skill_id),
  }));

  const enrichedPosts = posts.map((post) => ({
    ...post,
    author: post.author || allUsers.find((u) => u.id === post.author_id),
  }));

  const enrichedComments = comments.map((comm) => ({
    ...comm,
    author: comm.author || allUsers.find((u) => u.id === comm.author_id),
  }));

  return (
    <SkillSphereContext.Provider
      value={{
        currentUser,
        allUsers: enrichedUsers,
        skills,
        profileSkills: enrichedProfileSkills,
        posts: enrichedPosts,
        comments: enrichedComments,
        collaborationRequests,
        badges,
        supabaseConfig,
        activeView,
        setActiveView,
        viewingProfileId,
        setViewingProfileId,
        searchQuery,
        setSearchQuery,
        selectedSkillFilter,
        setSelectedSkillFilter,
        switchUser,
        updateProfile,
        addOrUpdateSkill,
        removeSkill,
        endorseSkill,
        getStudentBadges,
        awardBadge,
        createPost,
        deletePost,
        toggleLike,
        addComment,
        sendCollaborationRequest,
        saveSupabaseConfig,
        resetToSampleData,
      }}
    >
      {children}
    </SkillSphereContext.Provider>
  );
};


export const useSkillSphere = () => {
  const context = useContext(SkillSphereContext);
  if (!context) {
    throw new Error('useSkillSphere must be used within a SkillSphereProvider');
  }
  return context;
};
