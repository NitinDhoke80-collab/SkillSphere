import React, { useState } from 'react';
import { SkillSphereProvider, useSkillSphere } from './services/store';
import { Navbar } from './components/Navbar';
import { FeedView } from './components/FeedView';
import { ProfileView } from './components/ProfileView';
import { CollaboratorFinder } from './components/CollaboratorFinder';
import { SkillCatalogView } from './components/SkillCatalogView';
import { SqlSchemaViewer } from './components/SqlSchemaViewer';
import { CreatePostModal } from './components/CreatePostModal';
import { AuthModal } from './components/AuthModal';
import { CollabRequestModal } from './components/CollabRequestModal';
import { Post } from './types';
import {
  Compass,
  Users,
  Code2,
  User,
  Database,
  Plus,
  Github,
  Heart,
  ShieldCheck,
} from 'lucide-react';

function AppContent() {
  const { activeView, setActiveView, setViewingProfileId, currentUser } = useSkillSphere();

  const [isCreatePostOpen, setIsCreatePostOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [targetPostForCollab, setTargetPostForCollab] = useState<Post | null>(null);

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-sans selection:bg-blue-500/20 selection:text-blue-700">
      {/* Top Navbar */}
      <Navbar
        onOpenCreatePost={() => setIsCreatePostOpen(true)}
        onOpenAuthModal={() => setIsAuthModalOpen(true)}
        onOpenSupabaseModal={() => setActiveView('sql_schema')}
      />

      {/* Main View Router */}
      <main className="flex-1 pb-20 sm:pb-12">
        {activeView === 'feed' && (
          <FeedView
            onOpenCreatePost={() => setIsCreatePostOpen(true)}
            onOpenCollabModal={(post) => setTargetPostForCollab(post)}
          />
        )}

        {activeView === 'collaborators' && <CollaboratorFinder />}

        {activeView === 'skills' && <SkillCatalogView />}

        {activeView === 'profile' && <ProfileView />}

        {activeView === 'sql_schema' && <SqlSchemaViewer />}
      </main>

      {/* Mobile Floating Bottom Navigation Bar */}
      <nav className="sm:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200 px-4 py-2 flex items-center justify-around text-slate-600 shadow-lg">
        <button
          onClick={() => setActiveView('feed')}
          className={`flex flex-col items-center gap-1 text-[10px] font-medium transition-colors ${
            activeView === 'feed' ? 'text-blue-600 font-bold' : 'hover:text-slate-900'
          }`}
        >
          <Compass className="w-5 h-5" />
          <span>Feed</span>
        </button>

        <button
          onClick={() => setActiveView('collaborators')}
          className={`flex flex-col items-center gap-1 text-[10px] font-medium transition-colors ${
            activeView === 'collaborators' ? 'text-blue-600 font-bold' : 'hover:text-slate-900'
          }`}
        >
          <Users className="w-5 h-5" />
          <span>Match</span>
        </button>

        <button
          onClick={() => setIsCreatePostOpen(true)}
          className="w-10 h-10 rounded-full bg-blue-600 hover:bg-blue-700 text-white flex items-center justify-center -mt-4 shadow-md shadow-blue-600/30 transition-transform active:scale-95"
          aria-label="Create Post"
        >
          <Plus className="w-5 h-5" />
        </button>

        <button
          onClick={() => setActiveView('skills')}
          className={`flex flex-col items-center gap-1 text-[10px] font-medium transition-colors ${
            activeView === 'skills' ? 'text-blue-600 font-bold' : 'hover:text-slate-900'
          }`}
        >
          <Code2 className="w-5 h-5" />
          <span>Skills</span>
        </button>

        <button
          onClick={() => {
            setViewingProfileId(currentUser.id);
            setActiveView('profile');
          }}
          className={`flex flex-col items-center gap-1 text-[10px] font-medium transition-colors ${
            activeView === 'profile' ? 'text-blue-600 font-bold' : 'hover:text-slate-900'
          }`}
        >
          <User className="w-5 h-5" />
          <span>Profile</span>
        </button>
      </nav>

      {/* Footer */}
      <footer className="border-t border-slate-200 bg-white py-6 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="font-bold text-slate-800">SkillSphere</span>
            <span>·</span>
            <span>Student-First Skill Showcase &amp; Project Collaborator Platform</span>
          </div>

          <div className="flex items-center gap-4">
            <button
              onClick={() => setActiveView('sql_schema')}
              className="flex items-center gap-1 text-blue-600 hover:underline font-medium"
            >
              <Database className="w-3.5 h-3.5 text-blue-600" />
              Supabase SQL &amp; RLS
            </button>
            <span>·</span>
            <span className="flex items-center gap-1 text-slate-600">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              Row Level Security Active
            </span>
          </div>
        </div>
      </footer>

      {/* Global Modals */}
      <CreatePostModal
        isOpen={isCreatePostOpen}
        onClose={() => setIsCreatePostOpen(false)}
      />

      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
      />

      <CollabRequestModal
        isOpen={!!targetPostForCollab}
        onClose={() => setTargetPostForCollab(null)}
        targetPost={targetPostForCollab}
      />
    </div>
  );
}

export default function App() {
  return (
    <SkillSphereProvider>
      <AppContent />
    </SkillSphereProvider>
  );
}
