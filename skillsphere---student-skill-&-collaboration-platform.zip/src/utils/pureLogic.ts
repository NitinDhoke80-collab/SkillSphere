import { Post, Profile, ProfileSkill, Skill, StudentBadge, BadgeCategory } from '../types';

/**
 * Pure business logic utilities for SkillSphere.
 * Decoupled from React UI components for deterministic unit testing.
 */

/**
 * Filter students by search text (name, username, university, major, bio) and optional skill name.
 */
export function filterStudents(
  profiles: Profile[],
  profileSkills: ProfileSkill[],
  query: string,
  selectedSkill?: string
): Profile[] {
  const normalizedQuery = query.trim().toLowerCase();
  const normalizedSkill = selectedSkill ? selectedSkill.trim().toLowerCase() : '';

  return profiles.filter((profile) => {
    // If a specific skill filter is provided, student must have it
    if (normalizedSkill) {
      const hasSkill = profileSkills.some(
        (ps) =>
          ps.profile_id === profile.id &&
          ps.skill?.name.toLowerCase() === normalizedSkill
      );
      if (!hasSkill) return false;
    }

    if (!normalizedQuery) return true;

    // Check student text properties
    const inName = profile.full_name.toLowerCase().includes(normalizedQuery);
    const inUsername = profile.username.toLowerCase().includes(normalizedQuery);
    const inUniversity = profile.university.toLowerCase().includes(normalizedQuery);
    const inMajor = profile.major.toLowerCase().includes(normalizedQuery);
    const inBio = profile.bio.toLowerCase().includes(normalizedQuery);

    // Also check if any of their skills match query
    const studentSkills = profileSkills.filter((ps) => ps.profile_id === profile.id);
    const inSkills = studentSkills.some(
      (ps) => ps.skill?.name.toLowerCase().includes(normalizedQuery)
    );

    return inName || inUsername || inUniversity || inMajor || inBio || inSkills;
  });
}

/**
 * Filter and sort posts by type and optional search query.
 */
export function filterPosts(
  posts: Post[],
  activeTab: 'all' | 'collaborator_request' | 'achievement' | 'project_update',
  searchQuery?: string
): Post[] {
  const normalizedQuery = (searchQuery || '').trim().toLowerCase();

  return posts
    .filter((post) => {
      // Filter by tab
      if (activeTab !== 'all' && post.post_type !== activeTab) {
        return false;
      }

      // Filter by search query
      if (normalizedQuery) {
        const inContent = post.text_content.toLowerCase().includes(normalizedQuery);
        const inTitle = (post.project_title || '').toLowerCase().includes(normalizedQuery);
        const inAuthor = (post.author?.full_name || '').toLowerCase().includes(normalizedQuery);
        const inSkills = (post.looking_for_skills || []).some((s) =>
          s.toLowerCase().includes(normalizedQuery)
        );
        return inContent || inTitle || inAuthor || inSkills;
      }

      return true;
    })
    .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
}

/**
 * Calculate match percentage between a student's skills and a project's required skills.
 */
export function calculateSkillMatchScore(
  studentSkills: string[],
  requiredSkills: string[]
): { matchCount: number; matchPercentage: number; matchingSkills: string[] } {
  if (!requiredSkills || requiredSkills.length === 0) {
    return { matchCount: 0, matchPercentage: 100, matchingSkills: [] };
  }

  const normalizedStudent = new Set(studentSkills.map((s) => s.toLowerCase()));
  const matches = requiredSkills.filter((req) => normalizedStudent.has(req.toLowerCase()));

  const matchPercentage = Math.round((matches.length / requiredSkills.length) * 100);

  return {
    matchCount: matches.length,
    matchPercentage,
    matchingSkills: matches,
  };
}

/**
 * Validates post submission data.
 */
export function validatePostInput(
  textContent: string,
  postType: string,
  projectTitle?: string,
  lookingForSkills?: string[]
): { isValid: boolean; error?: string } {
  if (!textContent || textContent.trim().length === 0) {
    return { isValid: false, error: 'Post content cannot be empty.' };
  }

  if (textContent.trim().length < 5) {
    return { isValid: false, error: 'Post must be at least 5 characters.' };
  }

  if (textContent.length > 2000) {
    return { isValid: false, error: 'Post exceeds 2,000 character limit.' };
  }

  if (postType === 'collaborator_request') {
    if (!projectTitle || projectTitle.trim().length === 0) {
      return { isValid: false, error: 'Collaborator requests require a project title.' };
    }
    if (!lookingForSkills || lookingForSkills.length === 0) {
      return { isValid: false, error: 'Please specify at least one skill you are looking for.' };
    }
  }

  return { isValid: true };
}

/**
 * Format relative time display (e.g., '10m ago', '3h ago', '2d ago').
 */
export function formatRelativeTime(dateString: string, currentTimestamp = Date.now()): string {
  const postTime = new Date(dateString).getTime();
  const diffSeconds = Math.max(0, Math.floor((currentTimestamp - postTime) / 1000));

  if (diffSeconds < 60) return 'Just now';
  const diffMinutes = Math.floor(diffSeconds / 60);
  if (diffMinutes < 60) return `${diffMinutes}m ago`;
  const diffHours = Math.floor(diffMinutes / 60);
  if (diffHours < 24) return `${diffHours}h ago`;
  const diffDays = Math.floor(diffHours / 24);
  if (diffDays < 30) return `${diffDays}d ago`;
  const diffMonths = Math.floor(diffDays / 30);
  return `${diffMonths}mo ago`;
}

/**
 * Groups skills by category for catalogue presentation.
 */
export function groupSkillsByCategory(skills: Skill[]): Record<string, Skill[]> {
  const grouped: Record<string, Skill[]> = {};
  for (const skill of skills) {
    if (!grouped[skill.category]) {
      grouped[skill.category] = [];
    }
    grouped[skill.category].push(skill);
  }
  return grouped;
}


/**
 * Filter badges by category ('all', 'hackathon', 'academic', 'leadership').
 */
export function filterBadgesByCategory(
  badges: StudentBadge[],
  category: 'all' | BadgeCategory
): StudentBadge[] {
  if (category === 'all') return badges;
  return badges.filter((b) => b.category === category);
}

/**
 * Computes badge counts by category.
 */
export function getBadgeCounts(badges: StudentBadge[]): {
  total: number;
  hackathon: number;
  academic: number;
  leadership: number;
  verified: number;
} {
  return badges.reduce(
    (acc, b) => {
      acc.total += 1;
      if (b.category === 'hackathon') acc.hackathon += 1;
      if (b.category === 'academic') acc.academic += 1;
      if (b.category === 'leadership') acc.leadership += 1;
      if (b.verified) acc.verified += 1;
      return acc;
    },
    { total: 0, hackathon: 0, academic: 0, leadership: 0, verified: 0 }
  );
}

const TIER_ORDER: Record<string, number> = {
  gold: 1,
  special: 2,
  silver: 3,
  bronze: 4,
};

/**
 * Sorts badges by prestige tier (Gold > Special > Silver > Bronze) and recency.
 */
export function sortBadgesByTier(badges: StudentBadge[]): StudentBadge[] {
  return [...badges].sort((a, b) => {
    const tierA = TIER_ORDER[a.tier] || 99;
    const tierB = TIER_ORDER[b.tier] || 99;
    if (tierA !== tierB) return tierA - tierB;
    return new Date(b.created_at || b.date_earned).getTime() - new Date(a.created_at || a.date_earned).getTime();
  });
}

/**
 * Return top N badges for compact display on profile cards.
 */
export function getTopBadges(badges: StudentBadge[], limit = 3): StudentBadge[] {
  return sortBadgesByTier(badges).slice(0, limit);
}

