import test from 'node:test';
import assert from 'node:assert/strict';
import {
  filterStudents,
  filterPosts,
  calculateSkillMatchScore,
  validatePostInput,
  formatRelativeTime,
  groupSkillsByCategory,
  filterBadgesByCategory,
  getBadgeCounts,
  sortBadgesByTier,
  getTopBadges,
} from './pureLogic';
import { Profile, ProfileSkill, Skill, Post, StudentBadge } from '../types';

const mockProfiles: Profile[] = [
  {
    id: 'user-1',
    username: 'alexrivera',
    full_name: 'Alex Rivera',
    avatar_url: '',
    university: 'UC Berkeley',
    major: 'Computer Science & AI',
    grad_year: 2026,
    bio: 'Building autonomous drone navigation systems.',
    learning_goals: ['ROS2', 'Reinforcement Learning'],
    created_at: '2026-01-01T00:00:00Z',
    updated_at: '2026-01-01T00:00:00Z',
  },
  {
    id: 'user-2',
    username: 'mayachen',
    full_name: 'Maya Chen',
    avatar_url: '',
    university: 'Stanford University',
    major: 'Symbolic Systems & Design',
    grad_year: 2025,
    bio: 'Passionate about accessible UI design and React component libraries.',
    learning_goals: ['WebGL', 'Design Systems'],
    created_at: '2026-01-02T00:00:00Z',
    updated_at: '2026-01-02T00:00:00Z',
  },
];

const mockSkills: Skill[] = [
  { id: 'sk-1', name: 'React', category: 'Web Development', description: '', verified_count: 50 },
  { id: 'sk-2', name: 'PyTorch', category: 'AI & Machine Learning', description: '', verified_count: 30 },
  { id: 'sk-3', name: 'Figma', category: 'UI/UX Design', description: '', verified_count: 25 },
];

const mockProfileSkills: ProfileSkill[] = [
  {
    id: 'ps-1',
    profile_id: 'user-1',
    skill_id: 'sk-2',
    skill: mockSkills[1],
    status: 'proficient',
    endorsements_count: 12,
    created_at: '2026-01-01T00:00:00Z',
  },
  {
    id: 'ps-2',
    profile_id: 'user-2',
    skill_id: 'sk-1',
    skill: mockSkills[0],
    status: 'proficient',
    endorsements_count: 18,
    created_at: '2026-01-01T00:00:00Z',
  },
];

test('filterStudents finds students by name, university, or skill', () => {
  const resultName = filterStudents(mockProfiles, mockProfileSkills, 'Alex');
  assert.equal(resultName.length, 1);
  assert.equal(resultName[0].username, 'alexrivera');

  const resultUni = filterStudents(mockProfiles, mockProfileSkills, 'Stanford');
  assert.equal(resultUni.length, 1);
  assert.equal(resultUni[0].username, 'mayachen');

  const resultSkill = filterStudents(mockProfiles, mockProfileSkills, '', 'PyTorch');
  assert.equal(resultSkill.length, 1);
  assert.equal(resultSkill[0].username, 'alexrivera');

  const resultNoMatch = filterStudents(mockProfiles, mockProfileSkills, 'MIT');
  assert.equal(resultNoMatch.length, 0);
});

test('calculateSkillMatchScore accurately measures candidate fit', () => {
  const candidateSkills = ['React', 'TypeScript', 'Tailwind CSS', 'Next.js'];
  const projectNeeds = ['React', 'Next.js', 'PostgreSQL'];

  const score = calculateSkillMatchScore(candidateSkills, projectNeeds);
  assert.equal(score.matchCount, 2);
  assert.equal(score.matchPercentage, 67); // 2 out of 3 ~ 67%
  assert.deepEqual(score.matchingSkills, ['React', 'Next.js']);
});

test('validatePostInput enforces validation rules', () => {
  // Empty post
  const emptyCheck = validatePostInput('', 'general');
  assert.equal(emptyCheck.isValid, false);
  assert.match(emptyCheck.error || '', /empty/i);

  // Short post
  const shortCheck = validatePostInput('hi', 'general');
  assert.equal(shortCheck.isValid, false);

  // Valid general post
  const validGeneral = validatePostInput('Just published our open-source React dashboard!', 'general');
  assert.equal(validGeneral.isValid, true);

  // Collaborator request missing project title
  const collabMissingTitle = validatePostInput(
    'Looking for a backend dev for our hackathon project',
    'collaborator_request',
    '',
    ['Go', 'Postgres']
  );
  assert.equal(collabMissingTitle.isValid, false);
  assert.match(collabMissingTitle.error || '', /title/i);

  // Collaborator request missing skills
  const collabMissingSkills = validatePostInput(
    'Looking for a backend dev for our hackathon project',
    'collaborator_request',
    'FinTech App',
    []
  );
  assert.equal(collabMissingSkills.isValid, false);
  assert.match(collabMissingSkills.error || '', /skill/i);
});

test('formatRelativeTime returns readable elapsed time', () => {
  const now = 1774300000000;
  const justNow = new Date(now - 10 * 1000).toISOString();
  const minsAgo = new Date(now - 15 * 60 * 1000).toISOString();
  const hoursAgo = new Date(now - 4 * 3600 * 1000).toISOString();
  const daysAgo = new Date(now - 2 * 86400 * 1000).toISOString();

  assert.equal(formatRelativeTime(justNow, now), 'Just now');
  assert.equal(formatRelativeTime(minsAgo, now), '15m ago');
  assert.equal(formatRelativeTime(hoursAgo, now), '4h ago');
  assert.equal(formatRelativeTime(daysAgo, now), '2d ago');
});

test('groupSkillsByCategory categorizes skills properly', () => {
  const grouped = groupSkillsByCategory(mockSkills);
  assert.ok(grouped['Web Development']);
  assert.equal(grouped['Web Development'].length, 1);
  assert.equal(grouped['AI & Machine Learning'].length, 1);
  assert.equal(grouped['UI/UX Design'].length, 1);
});

const mockBadges: StudentBadge[] = [
  {
    id: 'b-1',
    student_id: 'user-1',
    category: 'hackathon',
    title: 'CalHacks 1st Place',
    issuer: 'Major League Hacking',
    date_earned: 'Fall 2025',
    description: 'Autonomous drone project winner',
    icon_name: 'Trophy',
    tier: 'gold',
    verified: true,
    created_at: '2025-11-01T00:00:00Z',
  },
  {
    id: 'b-2',
    student_id: 'user-1',
    category: 'academic',
    title: "Dean's Honors List",
    issuer: 'UC Berkeley',
    date_earned: 'Spring 2025',
    description: 'Top 5% GPA in EECS',
    icon_name: 'GraduationCap',
    tier: 'silver',
    verified: true,
    created_at: '2025-05-15T00:00:00Z',
  },
  {
    id: 'b-3',
    student_id: 'user-1',
    category: 'academic',
    title: 'Edge AI Research Fellow',
    issuer: 'BAIR Lab',
    date_earned: 'Fall 2025',
    description: 'SLAM pipeline research',
    icon_name: 'BookOpen',
    tier: 'bronze',
    verified: false,
    created_at: '2025-09-01T00:00:00Z',
  },
];

test('filterBadgesByCategory filters by category or returns all', () => {
  const all = filterBadgesByCategory(mockBadges, 'all');
  assert.equal(all.length, 3);

  const hackathons = filterBadgesByCategory(mockBadges, 'hackathon');
  assert.equal(hackathons.length, 1);
  assert.equal(hackathons[0].title, 'CalHacks 1st Place');

  const academics = filterBadgesByCategory(mockBadges, 'academic');
  assert.equal(academics.length, 2);

  const leadership = filterBadgesByCategory(mockBadges, 'leadership');
  assert.equal(leadership.length, 0);
});

test('getBadgeCounts calculates breakdown and verified count', () => {
  const counts = getBadgeCounts(mockBadges);
  assert.equal(counts.total, 3);
  assert.equal(counts.hackathon, 1);
  assert.equal(counts.academic, 2);
  assert.equal(counts.leadership, 0);
  assert.equal(counts.verified, 2);
});

test('sortBadgesByTier prioritizes Gold, then Silver, then Bronze', () => {
  const sorted = sortBadgesByTier(mockBadges);
  assert.equal(sorted[0].tier, 'gold');
  assert.equal(sorted[1].tier, 'silver');
  assert.equal(sorted[2].tier, 'bronze');

  const top2 = getTopBadges(mockBadges, 2);
  assert.equal(top2.length, 2);
  assert.equal(top2[0].title, 'CalHacks 1st Place');
  assert.equal(top2[1].title, "Dean's Honors List");
});

