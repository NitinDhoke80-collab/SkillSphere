/**
 * Supabase PostgreSQL SQL DDL & Row Level Security (RLS) Script
 * Designed for SkillSphere: Student-First Social & Skill Collaboration Platform.
 */

export const SUPABASE_SQL_SCRIPT = `-- ==============================================================================
-- SKILLSPHERE: SUPABASE POSTGRESQL SCHEMA & ROW LEVEL SECURITY (RLS)
-- Platform: College Student Skill Showcase, Social Feed & Project Collaborators
-- ==============================================================================

-- 1. EXTENSIONS
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ==============================================================================
-- 2. TABLES DEFINITIONS
-- ==============================================================================

-- PROFILES TABLE
-- Extends Supabase auth.users with public student credentials and private growth areas
CREATE TABLE public.profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    username TEXT UNIQUE NOT NULL,
    full_name TEXT NOT NULL,
    avatar_url TEXT DEFAULT 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
    university TEXT NOT NULL,
    major TEXT NOT NULL,
    grad_year INT NOT NULL CHECK (grad_year >= 2020 AND grad_year <= 2035),
    bio TEXT DEFAULT '',
    learning_goals TEXT[] DEFAULT '{}',
    -- Private columns: only owner can view or edit (protected by RLS & view)
    private_weaknesses TEXT DEFAULT '',
    contact_email TEXT DEFAULT '',
    github_url TEXT DEFAULT '',
    linkedin_url TEXT DEFAULT '',
    portfolio_url TEXT DEFAULT '',
    created_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL,
    updated_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- REUSABLE SKILL CATALOGUE TABLE
CREATE TABLE public.skills (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT UNIQUE NOT NULL,
    category TEXT NOT NULL CHECK (category IN (
        'Web Development',
        'AI & Machine Learning',
        'Systems & Cloud',
        'UI/UX Design',
        'Data Science',
        'Mobile & Game'
    )),
    description TEXT DEFAULT '',
    verified_count INT DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- PROFILE_SKILLS (Student <-> Skill M2M with status and endorsements)
CREATE TABLE public.profile_skills (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    profile_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    skill_id UUID NOT NULL REFERENCES public.skills(id) ON DELETE CASCADE,
    status TEXT NOT NULL CHECK (status IN ('proficient', 'learning', 'want_to_learn')),
    endorsements_count INT DEFAULT 0 CHECK (endorsements_count >= 0),
    created_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL,
    UNIQUE (profile_id, skill_id)
);

-- POSTS TABLE (Social feed, project collaborator calls, hackathon achievements)
CREATE TABLE public.posts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    author_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    post_type TEXT NOT NULL CHECK (post_type IN (
        'project_update',
        'achievement',
        'collaborator_request',
        'general'
    )),
    text_content TEXT NOT NULL CHECK (char_length(trim(text_content)) > 0),
    image_path TEXT,
    project_title TEXT,
    project_repo TEXT,
    looking_for_skills TEXT[] DEFAULT '{}',
    created_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL,
    updated_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- LIKES TABLE (Unique pair linking post and student user)
CREATE TABLE public.likes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    post_id UUID NOT NULL REFERENCES public.posts(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL,
    UNIQUE (post_id, user_id)
);

-- COMMENTS TABLE
CREATE TABLE public.comments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    post_id UUID NOT NULL REFERENCES public.posts(id) ON DELETE CASCADE,
    author_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    text_content TEXT NOT NULL CHECK (char_length(trim(text_content)) > 0),
    created_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- BADGES TABLE (Hackathon Wins, Verified Academic Milestones & Fellowships)
CREATE TABLE public.badges (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    student_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    category TEXT NOT NULL CHECK (category IN ('hackathon', 'academic', 'leadership')),
    title TEXT NOT NULL,
    issuer TEXT NOT NULL,
    date_earned TEXT NOT NULL,
    description TEXT DEFAULT '',
    icon_name TEXT DEFAULT 'Trophy',
    tier TEXT NOT NULL CHECK (tier IN ('gold', 'silver', 'bronze', 'special')),
    verification_url TEXT,
    verified BOOLEAN DEFAULT true,
    verifier_name TEXT,
    created_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- ==============================================================================
-- 3. ROW LEVEL SECURITY (RLS) POLICIES
-- Strict privacy rules: public can read public items, only owner can modify
-- ==============================================================================

-- Enable RLS across all tables
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.skills ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.profile_skills ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.posts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.likes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.comments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.badges ENABLE ROW LEVEL SECURITY;


-- ------------------------------------------------------------------------------
-- PROFILES RLS
-- Security guarantee: Anyone authenticated can view public profiles.
-- Private fields (private_weaknesses, contact_email) are accessible only by the owner.
-- ------------------------------------------------------------------------------
CREATE POLICY "Public profiles are viewable by all authenticated users"
ON public.profiles FOR SELECT
TO authenticated, anon
USING (true);

CREATE POLICY "Users can insert their own profile"
ON public.profiles FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can update their own profile"
ON public.profiles FOR UPDATE
TO authenticated
USING (auth.uid() = id)
WITH CHECK (auth.uid() = id);

-- Secure Public View omitting private_weaknesses and contact_email for external viewers
CREATE OR REPLACE VIEW public.public_profiles AS
SELECT
    id,
    username,
    full_name,
    avatar_url,
    university,
    major,
    grad_year,
    bio,
    learning_goals,
    github_url,
    linkedin_url,
    portfolio_url,
    created_at
FROM public.profiles;

-- ------------------------------------------------------------------------------
-- SKILLS RLS (Reusable Catalogue)
-- All users can view skills; authenticated students can register new skills
-- ------------------------------------------------------------------------------
CREATE POLICY "Skills are viewable by everyone"
ON public.skills FOR SELECT
TO authenticated, anon
USING (true);

CREATE POLICY "Authenticated users can contribute new skills"
ON public.skills FOR INSERT
TO authenticated
WITH CHECK (true);

-- ------------------------------------------------------------------------------
-- PROFILE_SKILLS RLS
-- Anyone can see skills tagged to a profile; students can only modify their own
-- ------------------------------------------------------------------------------
CREATE POLICY "Profile skills are viewable by everyone"
ON public.profile_skills FOR SELECT
TO authenticated, anon
USING (true);

CREATE POLICY "Users can add skills to their own profile"
ON public.profile_skills FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = profile_id);

CREATE POLICY "Users can update their own profile skills"
ON public.profile_skills FOR UPDATE
TO authenticated
USING (auth.uid() = profile_id)
WITH CHECK (auth.uid() = profile_id);

CREATE POLICY "Users can delete their own profile skills"
ON public.profile_skills FOR DELETE
TO authenticated
USING (auth.uid() = profile_id);

-- ------------------------------------------------------------------------------
-- POSTS RLS (Social Feed & Collaborator Requests)
-- Chronological feed is publicly readable; users only insert/edit/delete their own
-- ------------------------------------------------------------------------------
CREATE POLICY "Posts are viewable by all authenticated users"
ON public.posts FOR SELECT
TO authenticated, anon
USING (true);

CREATE POLICY "Users can create posts"
ON public.posts FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = author_id);

CREATE POLICY "Users can update their own posts"
ON public.posts FOR UPDATE
TO authenticated
USING (auth.uid() = author_id)
WITH CHECK (auth.uid() = author_id);

CREATE POLICY "Users can delete their own posts"
ON public.posts FOR DELETE
TO authenticated
USING (auth.uid() = author_id);

-- ------------------------------------------------------------------------------
-- LIKES RLS
-- Likes are viewable; users can only add/remove their own likes
-- ------------------------------------------------------------------------------
CREATE POLICY "Likes are viewable by all"
ON public.likes FOR SELECT
TO authenticated, anon
USING (true);

CREATE POLICY "Users can like posts"
ON public.likes FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can unlike posts"
ON public.likes FOR DELETE
TO authenticated
USING (auth.uid() = user_id);

-- ------------------------------------------------------------------------------
-- COMMENTS RLS
-- Comments are viewable; users can only author or remove their own comments
-- ------------------------------------------------------------------------------
CREATE POLICY "Comments are viewable by everyone"
ON public.comments FOR SELECT
TO authenticated, anon
USING (true);

CREATE POLICY "Users can post comments"
ON public.comments FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = author_id);

CREATE POLICY "Users can update their own comments"
ON public.comments FOR UPDATE
TO authenticated
USING (auth.uid() = author_id)
WITH CHECK (auth.uid() = author_id);

CREATE POLICY "Users can delete their own comments"
ON public.comments FOR DELETE
TO authenticated
USING (auth.uid() = author_id);

-- ------------------------------------------------------------------------------
-- BADGES RLS (Verified Academic Milestones & Hackathon Honors)
-- Credentials are publicly readable by students and recruiters
-- ------------------------------------------------------------------------------
CREATE POLICY "Student badges are viewable by everyone"
ON public.badges FOR SELECT
TO authenticated, anon
USING (true);

CREATE POLICY "Authenticated users or verified organizations can award badges"
ON public.badges FOR INSERT
TO authenticated
WITH CHECK (true);

-- ==============================================================================
-- 4. AUTOMATIC TRIGGERS & FUNCTIONS
-- ==============================================================================

-- Automatically create profile on auth.users sign up
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger AS $$
BEGIN
    INSERT INTO public.profiles (
        id,
        username,
        full_name,
        avatar_url,
        university,
        major,
        grad_year,
        bio,
        learning_goals,
        contact_email
    ) VALUES (
        new.id,
        coalesce(new.raw_user_meta_data->>'username', split_part(new.email, '@', 1)),
        coalesce(new.raw_user_meta_data->>'full_name', 'Student Fellow'),
        coalesce(new.raw_user_meta_data->>'avatar_url', 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150'),
        coalesce(new.raw_user_meta_data->>'university', 'University Campus'),
        coalesce(new.raw_user_meta_data->>'major', 'Computer Science'),
        coalesce((new.raw_user_meta_data->>'grad_year')::int, 2026),
        'Excited to build ambitious student projects and learn new technologies.',
        ARRAY['Full-Stack Development', 'System Design'],
        new.email
    );
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger hook on Supabase Auth table
CREATE OR REPLACE TRIGGER on_auth_user_created
    AFTER INSERT ON auth.users
    FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Auto update timestamp trigger
CREATE OR REPLACE FUNCTION public.set_current_timestamp_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = timezone('utc'::text, now());
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER set_profiles_updated_at
    BEFORE UPDATE ON public.profiles
    FOR EACH ROW EXECUTE FUNCTION public.set_current_timestamp_updated_at();

CREATE TRIGGER set_posts_updated_at
    BEFORE UPDATE ON public.posts
    FOR EACH ROW EXECUTE FUNCTION public.set_current_timestamp_updated_at();

-- ==============================================================================
-- 5. SUPABASE STORAGE BUCKETS SETUP
-- ==============================================================================
INSERT INTO storage.buckets (id, name, public)
VALUES ('post-images', 'post-images', true),
       ('avatars', 'avatars', true)
ON CONFLICT (id) DO NOTHING;

-- Storage policies: Public can read, authenticated can upload
CREATE POLICY "Public Read post-images"
ON storage.objects FOR SELECT
USING (bucket_id = 'post-images');

CREATE POLICY "Authenticated user upload post-images"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (bucket_id = 'post-images' AND auth.uid() = (storage.foldername(name))[1]::uuid);
`;
